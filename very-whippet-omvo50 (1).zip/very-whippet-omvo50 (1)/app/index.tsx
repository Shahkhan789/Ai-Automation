import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import * as ImagePicker from "expo-image-picker";
import * as Haptics from "expo-haptics";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";

import Header from "@/components/Header";
import UploadSection from "@/components/UploadSection";
import TradingTypeSelector from "@/components/TradingTypeSelector";
import TimeframeSelector from "@/components/TimeframeSelector";
import EnhancedSignalCard from "@/components/EnhancedSignalCard";
import RecentSignals from "@/components/RecentSignals";
import AIInsights from "@/components/AIInsights";
import MarketSentiment from "@/components/MarketSentiment";

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

export default function TradingSignalApp() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentSignal, setCurrentSignal] = useState<any>(null);
  const [selectedTradingType, setSelectedTradingType] = useState("Forex");
  const [selectedTimeframe, setSelectedTimeframe] = useState("1m");
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [aiInsights, setAiInsights] = useState<any>(null);

  const recentSignals = useQuery(api.tradingSignals.list);
  const createSignal = useMutation(api.tradingSignals.create);
  const generateUploadUrl = useMutation(api.tradingSignals.generateUploadUrl);

  const pickImage = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setSelectedImage(result.assets[0].uri);
      setCurrentSignal(null);
      setAiInsights(null);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage) {
      Alert.alert("Error", "Please select an image first");
      return;
    }

    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }

    setIsAnalyzing(true);
    setAnalysisProgress(0);

    // Advanced AI analysis simulation with sophisticated progress steps
    const analysisSteps = [
      { step: "Initializing quantum neural networks...", progress: 8 },
      { step: "Preprocessing image with computer vision algorithms...", progress: 15 },
      { step: "Extracting candlestick patterns and formations...", progress: 25 },
      { step: "Analyzing 50+ technical indicators (RSI, MACD, Bollinger, Ichimoku)...", progress: 40 },
      { step: "Processing real-time market sentiment and volume flow...", progress: 55 },
      { step: "Running Monte Carlo risk assessment simulations...", progress: 70 },
      { step: "Cross-referencing with 10 years of historical market data...", progress: 82 },
      { step: "Applying machine learning pattern recognition models...", progress: 92 },
      { step: "Finalizing AI recommendations with confidence scoring...", progress: 100 }
    ];

    for (const { step, progress } of analysisSteps) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setAnalysisProgress(progress);
    }

    // Advanced AI analysis with sophisticated market logic
    const marketAnalysis = generateAdvancedMarketAnalysis(selectedTradingType, selectedTimeframe);
    
    const mockSignal = {
      signal: marketAnalysis.signal,
      confidence: marketAnalysis.confidence,
      reasoning: marketAnalysis.reasoning,
      riskManagement: marketAnalysis.riskManagement,
      marketType: selectedTradingType,
      timeframe: selectedTimeframe,
      imageUrl: selectedImage,
      entryPrice: marketAnalysis.entryPrice,
      stopLoss: marketAnalysis.stopLoss,
      takeProfit: marketAnalysis.takeProfit,
      riskReward: marketAnalysis.riskReward,
    };

    // Generate enhanced AI insights with market correlation
    const insights = generateAdvancedAIInsights(selectedTradingType, marketAnalysis.signal, marketAnalysis.confidence, selectedTimeframe);

    setCurrentSignal(mockSignal);
    setAiInsights(insights);
    setIsAnalyzing(false);
    setAnalysisProgress(0);

    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const generateAdvancedMarketAnalysis = (tradingType: string, timeframe: string) => {
    // Advanced market simulation with realistic patterns
    const currentTime = new Date();
    const hour = currentTime.getHours();
    const dayOfWeek = currentTime.getDay();
    
    // Market session analysis
    const isAsianSession = hour >= 0 && hour < 8;
    const isLondonSession = hour >= 8 && hour < 16;
    const isNYSession = hour >= 13 && hour < 21;
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    
    // Volatility based on session and timeframe
    let baseVolatility = 0.5;
    if (isLondonSession || isNYSession) baseVolatility += 0.3;
    if (timeframe.includes('s') || timeframe === '1m') baseVolatility += 0.4;
    if (timeframe.includes('d') || timeframe.includes('w')) baseVolatility -= 0.2;
    
    // Market-specific adjustments
    const marketFactors = getMarketSpecificFactors(tradingType, timeframe);
    
    // Advanced signal generation with multiple factors
    const technicalScore = calculateTechnicalScore(timeframe, baseVolatility);
    const fundamentalScore = calculateFundamentalScore(tradingType, hour, dayOfWeek);
    const sentimentScore = calculateSentimentScore(tradingType, baseVolatility);
    
    const combinedScore = (technicalScore * 0.5) + (fundamentalScore * 0.3) + (sentimentScore * 0.2);
    
    let signal: "BUY" | "SELL" | "HOLD";
    let confidence: number;
    
    if (combinedScore > 0.65) {
      signal = "BUY";
      confidence = Math.min(95, 70 + (combinedScore - 0.65) * 100);
    } else if (combinedScore < 0.35) {
      signal = "SELL";
      confidence = Math.min(95, 70 + (0.35 - combinedScore) * 100);
    } else {
      signal = "HOLD";
      confidence = Math.max(55, 80 - Math.abs(combinedScore - 0.5) * 100);
    }
    
    // Generate sophisticated analysis
    const analysis = generateSophisticatedAnalysis(
      tradingType, 
      timeframe, 
      signal, 
      confidence, 
      technicalScore, 
      fundamentalScore, 
      sentimentScore,
      marketFactors
    );
    
    return {
      signal,
      confidence: Math.round(confidence),
      ...analysis
    };
  };

  const getMarketSpecificFactors = (tradingType: string, timeframe: string) => {
    const factors: any = {
      volatilityMultiplier: 1,
      trendStrength: Math.random(),
      volumeProfile: Math.random(),
      institutionalFlow: Math.random()
    };
    
    switch (tradingType) {
      case "Forex":
        factors.volatilityMultiplier = 0.8;
        factors.economicEvents = Math.random() > 0.7;
        factors.centralBankPolicy = Math.random() > 0.8;
        break;
      case "Crypto":
        factors.volatilityMultiplier = 1.5;
        factors.whaleActivity = Math.random() > 0.6;
        factors.defiMetrics = Math.random();
        factors.socialSentiment = Math.random();
        break;
      case "Binary Options":
        factors.volatilityMultiplier = 1.2;
        factors.expiryOptimization = true;
        factors.payoutRatio = 0.8 + Math.random() * 0.15;
        break;
      case "Stocks":
        factors.volatilityMultiplier = 0.9;
        factors.earningsProximity = Math.random() > 0.85;
        factors.sectorRotation = Math.random();
        factors.optionsFlow = Math.random();
        break;
    }
    
    return factors;
  };

  const calculateTechnicalScore = (timeframe: string, volatility: number) => {
    // Simulate multiple technical indicators
    const rsi = 30 + Math.random() * 40; // 30-70 range
    const macdSignal = Math.random() > 0.5 ? 1 : -1;
    const bollingerPosition = Math.random(); // 0-1, where 0.5 is middle
    const volumeConfirmation = Math.random() > 0.4 ? 1 : 0;
    const trendAlignment = Math.random();
    
    // Weighted technical score
    let score = 0.5; // neutral base
    
    // RSI contribution
    if (rsi < 35) score += 0.2; // oversold, bullish
    else if (rsi > 65) score -= 0.2; // overbought, bearish
    
    // MACD contribution
    score += macdSignal * 0.15;
    
    // Bollinger Bands
    if (bollingerPosition < 0.2) score += 0.1; // near lower band
    else if (bollingerPosition > 0.8) score -= 0.1; // near upper band
    
    // Volume confirmation
    score += volumeConfirmation * 0.1;
    
    // Trend alignment
    score += (trendAlignment - 0.5) * 0.2;
    
    // Volatility adjustment
    score += (volatility - 0.5) * 0.1;
    
    return Math.max(0, Math.min(1, score));
  };

  const calculateFundamentalScore = (tradingType: string, hour: number, dayOfWeek: number) => {
    let score = 0.5;
    
    // Market session strength
    if (hour >= 8 && hour <= 16) score += 0.1; // London session
    if (hour >= 13 && hour <= 21) score += 0.1; // NY session overlap
    
    // Day of week effects
    if (dayOfWeek >= 1 && dayOfWeek <= 4) score += 0.05; // Mid-week strength
    if (dayOfWeek === 5) score -= 0.1; // Friday profit-taking
    
    // Market-specific fundamentals
    switch (tradingType) {
      case "Forex":
        // Economic calendar simulation
        if (Math.random() > 0.8) score += Math.random() * 0.2 - 0.1; // News impact
        break;
      case "Crypto":
        // Crypto-specific events
        if (Math.random() > 0.9) score += Math.random() * 0.3 - 0.15; // High impact events
        break;
      case "Stocks":
        // Earnings season, market open effects
        if (hour >= 9 && hour <= 10) score += 0.05; // Market open volatility
        if (hour >= 15 && hour <= 16) score += 0.05; // Market close effects
        break;
    }
    
    return Math.max(0, Math.min(1, score));
  };

  const calculateSentimentScore = (tradingType: string, volatility: number) => {
    let score = 0.5;
    
    // Simulate sentiment indicators
    const fearGreedIndex = Math.random(); // 0 = extreme fear, 1 = extreme greed
    const institutionalFlow = Math.random() > 0.6 ? 1 : -1;
    const retailSentiment = Math.random() > 0.5 ? 1 : -1;
    
    // Fear & Greed impact
    if (fearGreedIndex < 0.25) score += 0.15; // Extreme fear = contrarian buy
    else if (fearGreedIndex > 0.75) score -= 0.15; // Extreme greed = contrarian sell
    
    // Institutional vs retail
    score += institutionalFlow * 0.1;
    score += retailSentiment * 0.05;
    
    // Volatility sentiment
    if (volatility > 0.8) score -= 0.1; // High volatility = risk off
    
    return Math.max(0, Math.min(1, score));
  };

  const generateSophisticatedAnalysis = (
    tradingType: string, 
    timeframe: string, 
    signal: string, 
    confidence: number,
    technicalScore: number,
    fundamentalScore: number,
    sentimentScore: number,
    marketFactors: any
  ) => {
    // Advanced pattern library
    const bullishPatterns = [
      "Inverse Head and Shoulders Breakout", "Ascending Triangle with Volume Confirmation", 
      "Bull Flag Continuation Pattern", "Double Bottom Reversal with RSI Divergence",
      "Cup and Handle Formation", "Falling Wedge Breakout", "Hammer Reversal at Support",
      "Bullish Engulfing with Volume Spike", "Morning Star Reversal Pattern",
      "Symmetrical Triangle Upside Breakout", "Pennant Continuation Signal"
    ];
    
    const bearishPatterns = [
      "Head and Shoulders Top Formation", "Descending Triangle Breakdown",
      "Bear Flag Continuation", "Double Top Reversal with Momentum Divergence",
      "Rising Wedge Breakdown", "Shooting Star at Resistance", "Dark Cloud Cover",
      "Bearish Engulfing Pattern", "Evening Star Reversal", "Symmetrical Triangle Downside Break"
    ];
    
    const neutralPatterns = [
      "Doji Indecision at Key Level", "Spinning Top Consolidation",
      "Inside Bar Compression", "Symmetrical Triangle Formation",
      "Rectangle Consolidation Pattern", "Pennant Compression Phase"
    ];
    
    // Select appropriate patterns
    const patterns = signal === "BUY" ? bullishPatterns : 
                    signal === "SELL" ? bearishPatterns : neutralPatterns;
    const primaryPattern = patterns[Math.floor(Math.random() * patterns.length)];
    
    // Advanced technical indicators
    const indicators = [
      `RSI(14): ${(30 + Math.random() * 40).toFixed(1)} - ${signal === "BUY" ? "Oversold Recovery" : signal === "SELL" ? "Overbought Rejection" : "Neutral Zone"}`,
      `MACD: ${signal === "BUY" ? "Bullish Crossover" : signal === "SELL" ? "Bearish Crossover" : "Convergence"}`,
      `Bollinger Bands: ${signal === "BUY" ? "Lower Band Bounce" : signal === "SELL" ? "Upper Band Rejection" : "Middle Band Test"}`,
      `Stochastic: ${signal === "BUY" ? "Oversold Divergence" : signal === "SELL" ? "Overbought Divergence" : "Neutral"}`,
      `ADX: ${(20 + Math.random() * 60).toFixed(1)} - ${confidence > 80 ? "Strong Trend" : confidence > 60 ? "Moderate Trend" : "Weak Trend"}`,
      `Volume Profile: ${marketFactors.volumeProfile > 0.6 ? "Above Average" : "Below Average"} - ${signal === "BUY" ? "Accumulation" : signal === "SELL" ? "Distribution" : "Balanced"}`
    ];
    
    // Market-specific analysis
    const marketSpecificAnalysis = generateMarketSpecificAnalysis(tradingType, signal, confidence, marketFactors);
    
    // Risk calculations with advanced modeling
    const riskCalc = calculateAdvancedRisk(tradingType, timeframe, signal, confidence, marketFactors);
    
    const reasoning = `Advanced AI analysis identified ${primaryPattern} with ${confidence}% algorithmic confidence. 
    
Technical Analysis (Score: ${(technicalScore * 100).toFixed(1)}%): ${indicators.slice(0, 3).join(". ")}. 
    
Fundamental Analysis (Score: ${(fundamentalScore * 100).toFixed(1)}%): ${marketSpecificAnalysis.fundamental}
    
Sentiment Analysis (Score: ${(sentimentScore * 100).toFixed(1)}%): ${marketSpecificAnalysis.sentiment}
    
Multi-timeframe correlation analysis confirms ${signal.toLowerCase()} bias with ${confidence > 80 ? "high" : confidence > 60 ? "moderate" : "low"} conviction. Machine learning pattern recognition models show ${confidence}% probability of directional move within ${timeframe} timeframe.`;

    return {
      reasoning,
      riskManagement: marketSpecificAnalysis.riskManagement,
      entryPrice: riskCalc.entryPrice,
      stopLoss: riskCalc.stopLoss,
      takeProfit: riskCalc.takeProfit,
      riskReward: riskCalc.riskReward
    };
  };

  const generateMarketSpecificAnalysis = (tradingType: string, signal: string, confidence: number, marketFactors: any) => {
    const currentTime = new Date();
    const hour = currentTime.getHours();
    
    switch (tradingType) {
      case "Forex":
        return {
          fundamental: `Economic calendar analysis shows ${marketFactors.economicEvents ? "high-impact news pending" : "low-impact session"}. Central bank policy ${marketFactors.centralBankPolicy ? "supportive of direction" : "neutral stance"}. Cross-currency correlation analysis confirms ${signal.toLowerCase()} bias.`,
          sentiment: `Institutional flow shows ${marketFactors.institutionalFlow > 0.6 ? "strong buying pressure" : marketFactors.institutionalFlow < 0.4 ? "selling pressure" : "balanced positioning"}. Risk sentiment ${signal === "BUY" ? "improving" : signal === "SELL" ? "deteriorating" : "mixed"}.`,
          riskManagement: `Forex Strategy: Position sizing for ${(confidence / 20).toFixed(1)}% account risk. Monitor economic releases during ${hour >= 8 && hour <= 16 ? "London" : hour >= 13 && hour <= 21 ? "NY" : "Asian"} session. Consider correlation with major pairs and safe-haven flows.`
        };
        
      case "Crypto":
        return {
          fundamental: `On-chain metrics show ${marketFactors.whaleActivity ? "significant whale accumulation" : "retail-driven movement"}. DeFi protocol analysis indicates ${marketFactors.defiMetrics > 0.6 ? "strong ecosystem growth" : "consolidation phase"}. Network activity ${signal === "BUY" ? "increasing" : "stabilizing"}.`,
          sentiment: `Social sentiment analysis: ${marketFactors.socialSentiment > 0.7 ? "Extremely bullish" : marketFactors.socialSentiment < 0.3 ? "Bearish" : "Mixed"}. Fear & Greed Index suggests ${signal === "BUY" ? "oversold conditions" : signal === "SELL" ? "overbought levels" : "neutral territory"}.`,
          riskManagement: `Crypto Strategy: High volatility requires ${(confidence / 15).toFixed(1)}% position sizing. Monitor Bitcoin dominance and regulatory news. Set alerts for major support/resistance levels. Consider DeFi yield opportunities and staking rewards.`
        };
        
      case "Binary Options":
        const expiryTime = getOptimalExpiry(confidence, marketFactors);
        return {
          fundamental: `Binary options analysis optimized for ${expiryTime} expiry. Market microstructure shows ${confidence > 80 ? "high probability" : "moderate probability"} of directional move. Volatility clustering suggests ${signal === "BUY" ? "upward" : signal === "SELL" ? "downward" : "sideways"} bias.`,
          sentiment: `Options flow indicates ${marketFactors.payoutRatio > 0.85 ? "favorable" : "standard"} risk/reward with ${(marketFactors.payoutRatio * 100).toFixed(0)}% payout. Market maker positioning ${signal === "BUY" ? "supports bullish" : signal === "SELL" ? "supports bearish" : "neutral"} outlook.`,
          riskManagement: `Binary Strategy: Risk only 2-3% per trade with ${expiryTime} expiry. Expected payout: ${(marketFactors.payoutRatio * 100).toFixed(0)}%. Monitor for early exit opportunities if platform allows. Avoid trading during major news releases.`
        };
        
      case "Stocks":
        return {
          fundamental: `Equity analysis shows ${marketFactors.earningsProximity ? "earnings catalyst approaching" : "normal trading conditions"}. Sector rotation ${marketFactors.sectorRotation > 0.6 ? "favoring growth" : "favoring value"} stocks. Options flow indicates ${marketFactors.optionsFlow > 0.6 ? "bullish positioning" : "defensive positioning"}.`,
          sentiment: `Institutional sentiment: ${signal === "BUY" ? "Accumulation phase" : signal === "SELL" ? "Distribution phase" : "Consolidation"}. Dark pool activity ${confidence > 75 ? "confirms" : "mixed signals on"} directional bias. Analyst revisions ${signal === "BUY" ? "trending positive" : "mixed"}.`,
          riskManagement: `Equity Strategy: Consider market hours (9:30 AM - 4:00 PM ET) and after-hours volatility. Monitor earnings calendar and sector performance. Use ${(confidence / 25).toFixed(1)}% position sizing. Consider options strategies for leverage and hedging.`
        };
        
      default:
        return {
          fundamental: "Multi-asset analysis pending",
          sentiment: "Neutral market sentiment",
          riskManagement: "Standard risk management protocols"
        };
    }
  };

  const getOptimalExpiry = (confidence: number, marketFactors: any) => {
    if (confidence > 85) return "5 minutes";
    if (confidence > 75) return "2 minutes";
    if (confidence > 65) return "1 minute";
    return "30 seconds";
  };

  const calculateAdvancedRisk = (tradingType: string, timeframe: string, signal: string, confidence: number, marketFactors: any) => {
    // Advanced risk modeling
    const volatilityAdjustment = marketFactors.volatilityMultiplier;
    const timeframeRisk = getTimeframeRiskMultiplier(timeframe);
    const confidenceAdjustment = confidence / 100;
    
    const baseRisk = timeframeRisk * volatilityAdjustment * (1 + (1 - confidenceAdjustment));
    
    switch (tradingType) {
      case "Binary Options":
        const expiryTime = getOptimalExpiry(confidence, marketFactors);
        return {
          entryPrice: "Current Market Price",
          stopLoss: "N/A (Binary Options)",
          takeProfit: `Fixed Payout (${expiryTime})`,
          riskReward: `1:${marketFactors.payoutRatio.toFixed(2)} (${(marketFactors.payoutRatio * 100).toFixed(0)}% payout)`
        };
        
      case "Forex":
        const forexPrice = 1.0500 + (Math.random() * 0.5);
        const stopDistance = forexPrice * (baseRisk / 100);
        const profitDistance = stopDistance * (2 + Math.random() * 2);
        return {
          entryPrice: `${forexPrice.toFixed(4)} (EUR/USD)`,
          stopLoss: signal === "BUY" ? (forexPrice - stopDistance).toFixed(4) : (forexPrice + stopDistance).toFixed(4),
          takeProfit: signal === "BUY" ? (forexPrice + profitDistance).toFixed(4) : (forexPrice - profitDistance).toFixed(4),
          riskReward: `1:${(profitDistance / stopDistance).toFixed(1)}`
        };
        
      case "Crypto":
        const cryptoPrice = 35000 + (Math.random() * 30000);
        const cryptoStop = cryptoPrice * (baseRisk / 100);
        const cryptoProfit = cryptoStop * (1.5 + Math.random() * 2.5);
        return {
          entryPrice: `$${cryptoPrice.toFixed(0)} (BTC/USD)`,
          stopLoss: signal === "BUY" ? `$${(cryptoPrice - cryptoStop).toFixed(0)}` : `$${(cryptoPrice + cryptoStop).toFixed(0)}`,
          takeProfit: signal === "BUY" ? `$${(cryptoPrice + cryptoProfit).toFixed(0)}` : `$${(cryptoPrice - cryptoProfit).toFixed(0)}`,
          riskReward: `1:${(cryptoProfit / cryptoStop).toFixed(1)}`
        };
        
      case "Stocks":
        const stockPrice = 150 + (Math.random() * 200);
        const stockStop = stockPrice * (baseRisk / 100);
        const stockProfit = stockStop * (2 + Math.random() * 2);
        return {
          entryPrice: `$${stockPrice.toFixed(2)} (AAPL)`,
          stopLoss: signal === "BUY" ? `$${(stockPrice - stockStop).toFixed(2)}` : `$${(stockPrice + stockStop).toFixed(2)}`,
          takeProfit: signal === "BUY" ? `$${(stockPrice + stockProfit).toFixed(2)}` : `$${(stockPrice - stockProfit).toFixed(2)}`,
          riskReward: `1:${(stockProfit / stockStop).toFixed(1)}`
        };
        
      default:
        return {
          entryPrice: "Market Price",
          stopLoss: "Dynamic",
          takeProfit: "Target",
          riskReward: "1:2"
        };
    }
  };

  const getTimeframeRiskMultiplier = (timeframe: string) => {
    const riskMap: { [key: string]: number } = {
      "5s": 0.2, "30s": 0.3, "1m": 0.5, "2m": 0.7, "5m": 1.0, 
      "10m": 1.2, "15m": 1.5, "30m": 1.8, "1h": 2.2, "4h": 3.0, "1d": 4.5, "1w": 6.0
    };
    return riskMap[timeframe] || 1.5;
  };

  const generateAdvancedAIInsights = (tradingType: string, signal: string, confidence: number, timeframe: string) => {
    const marketConditions = [
      "Strong Trending Market", "Range-bound Consolidation", "High Volatility Breakout", 
      "Low Volatility Compression", "Reversal Zone Formation", "Continuation Pattern",
      "Institutional Accumulation", "Retail Distribution Phase", "News-Driven Movement"
    ];
    
    const volatilityLevels = ["Low", "Medium", "High", "Extreme"];
    
    const getAdvancedVolatility = (tf: string, tradingType: string) => {
      let baseVol = 1;
      if (["5s", "30s", "1m"].includes(tf)) baseVol = 3;
      else if (["2m", "5m", "10m"].includes(tf)) baseVol = 2;
      else if (["15m", "30m", "1h"].includes(tf)) baseVol = 1;
      else baseVol = 0;
      
      if (tradingType === "Crypto") baseVol = Math.min(3, baseVol + 1);
      if (tradingType === "Binary Options") baseVol = Math.min(3, baseVol + 1);
      
      return volatilityLevels[baseVol];
    };
    
    return {
      marketCondition: marketConditions[Math.floor(Math.random() * marketConditions.length)],
      sentiment: signal === "BUY" ? "Bullish" : signal === "SELL" ? "Bearish" : "Neutral",
      volatility: getAdvancedVolatility(timeframe, tradingType),
      keyLevels: {
        support: "AI-identified dynamic support with 89% accuracy",
        resistance: "Machine learning resistance zone with high probability",
        pivot: "Quantum-calculated pivot point for optimal entry timing"
      },
      newsImpact: confidence > 85 ? "High" : confidence > 70 ? "Medium" : "Low",
      institutionalFlow: signal === "BUY" ? "Strong institutional accumulation detected" : 
                        signal === "SELL" ? "Institutional distribution pattern observed" : 
                        "Balanced institutional positioning",
      riskLevel: confidence > 85 ? "Low" : confidence > 70 ? "Medium" : "High",
      aiConfidence: {
        patternRecognition: Math.floor(Math.random() * 15) + 85, // 85-100%
        technicalAnalysis: Math.floor(Math.random() * 20) + 80, // 80-100%
        marketContext: Math.floor(Math.random() * 25) + 75 // 75-100%
      },
      advancedMetrics: {
        volatilityForecast: `${(Math.random() * 3 + 1).toFixed(1)}x current levels`,
        probabilityMatrix: `${confidence}% directional, ${100 - confidence}% reversal`,
        riskAdjustedReturn: `${(confidence * 0.02).toFixed(1)}% expected return`,
        sharpeRatio: (Math.random() * 2 + 1).toFixed(2),
        maxDrawdown: `${(Math.random() * 5 + 2).toFixed(1)}% estimated`,
        winRate: `${Math.floor(Math.random() * 20) + 65}% historical accuracy`
      }
    };
  };

  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  return (
    <LinearGradient
      colors={["#1a2a6c", "#2c3e50", "#1a2a6c"]}
      style={styles.container}
    >
      <SafeAreaView style={styles.safeArea}>
        <ScrollView 
          style={styles.scrollView} 
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            isTablet && styles.scrollContentTablet,
            isLargeScreen && styles.scrollContentLarge
          ]}
        >
          <Header />
          
          <View style={[
            styles.content,
            isTablet && styles.contentTablet,
            isLargeScreen && styles.contentLarge
          ]}>
            <View style={[
              styles.mainSection,
              isTablet && styles.mainSectionTablet,
              isLargeScreen && styles.mainSectionLarge
            ]}>
              <TradingTypeSelector
                selectedType={selectedTradingType}
                onTypeSelect={setSelectedTradingType}
              />

              <TimeframeSelector
                selectedTimeframe={selectedTimeframe}
                onTimeframeSelect={setSelectedTimeframe}
                tradingType={selectedTradingType}
              />

              <UploadSection
                selectedImage={selectedImage}
                onPickImage={pickImage}
                onAnalyze={analyzeImage}
                isAnalyzing={isAnalyzing}
                analysisProgress={analysisProgress}
              />

              {currentSignal && (
                <>
                  <EnhancedSignalCard signal={currentSignal} />
                  {aiInsights && (
                    <>
                      <AIInsights insights={aiInsights} />
                      <MarketSentiment 
                        sentiment={aiInsights.sentiment}
                        volatility={aiInsights.volatility}
                        marketCondition={aiInsights.marketCondition}
                      />
                    </>
                  )}
                </>
              )}
            </View>

            <View style={[
              styles.sideSection,
              isTablet && styles.sideSectionTablet,
              isLargeScreen && styles.sideSectionLarge
            ]}>
              <RecentSignals signals={recentSignals} />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  scrollContentTablet: {
    paddingHorizontal: 40,
  },
  scrollContentLarge: {
    paddingHorizontal: 80,
    maxWidth: 1400,
    alignSelf: 'center',
    width: '100%',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  contentTablet: {
    padding: 30,
    paddingBottom: 60,
  },
  contentLarge: {
    padding: 40,
    paddingBottom: 80,
    flexDirection: 'row',
    gap: 40,
  },
  mainSection: {
    width: '100%',
  },
  mainSectionTablet: {
    width: '100%',
  },
  mainSectionLarge: {
    flex: 2,
    minWidth: 600,
  },
  sideSection: {
    width: '100%',
    marginTop: 20,
  },
  sideSectionTablet: {
    marginTop: 30,
  },
  sideSectionLarge: {
    flex: 1,
    marginTop: 0,
    minWidth: 400,
  },
});