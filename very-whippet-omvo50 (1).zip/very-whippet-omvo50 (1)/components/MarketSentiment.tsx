import React from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

const { width: screenWidth } = Dimensions.get('window');

interface MarketSentimentProps {
  sentiment: string;
  volatility: string;
  marketCondition: string;
}

export default function MarketSentiment({ sentiment, volatility, marketCondition }: MarketSentimentProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "Bullish": return "#2ecc71";
      case "Bearish": return "#e74c3c";
      case "Neutral": return "#95a5a6";
      case "Mixed": return "#f39c12";
      default: return "#3498db";
    }
  };

  const getVolatilityIntensity = (volatility: string) => {
    switch (volatility) {
      case "Low": return 0.3;
      case "Medium": return 0.6;
      case "High": return 0.8;
      case "Extreme": return 1.0;
      default: return 0.5;
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case "Bullish": return "trending-up";
      case "Bearish": return "trending-down";
      case "Neutral": return "remove";
      case "Mixed": return "swap-horizontal";
      default: return "analytics";
    }
  };

  const sentimentColor = getSentimentColor(sentiment);
  const volatilityIntensity = getVolatilityIntensity(volatility);

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <Text style={[
        styles.sectionTitle,
        isTablet && styles.sectionTitleTablet,
        isLargeScreen && styles.sectionTitleLarge
      ]}>
        Market Sentiment Analysis
      </Text>
      
      <View style={[
        styles.card,
        isTablet && styles.cardTablet,
        isLargeScreen && styles.cardLarge
      ]}>
        {/* Sentiment Gauge */}
        <View style={[
          styles.gaugeContainer,
          isTablet && styles.gaugeContainerTablet,
          isLargeScreen && styles.gaugeContainerLarge
        ]}>
          <View style={styles.gaugeHeader}>
            <Ionicons 
              name={getSentimentIcon(sentiment) as any} 
              size={isLargeScreen ? 32 : isTablet ? 28 : 24} 
              color={sentimentColor} 
            />
            <Text style={[
              styles.sentimentText,
              { color: sentimentColor },
              isTablet && styles.sentimentTextTablet,
              isLargeScreen && styles.sentimentTextLarge
            ]}>
              {sentiment} Sentiment
            </Text>
          </View>
          
          <View style={[
            styles.gaugeBackground,
            isTablet && styles.gaugeBackgroundTablet,
            isLargeScreen && styles.gaugeBackgroundLarge
          ]}>
            <LinearGradient
              colors={[sentimentColor, `${sentimentColor}80`]}
              style={[
                styles.gaugeFill,
                { width: `${Math.min(volatilityIntensity * 100, 100)}%` },
                isTablet && styles.gaugeFillTablet,
                isLargeScreen && styles.gaugeFillLarge
              ]}
            />
          </View>
        </View>

        {/* Market Metrics Grid */}
        <View style={[
          styles.metricsGrid,
          isTablet && styles.metricsGridTablet,
          isLargeScreen && styles.metricsGridLarge
        ]}>
          <View style={[styles.metricCard, { borderLeftColor: "#3498db" }]}>
            <Ionicons 
              name="pulse" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#3498db" 
            />
            <View style={styles.metricContent}>
              <Text style={[
                styles.metricLabel,
                isTablet && styles.metricLabelTablet,
                isLargeScreen && styles.metricLabelLarge
              ]}>
                Volatility
              </Text>
              <Text style={[
                styles.metricValue,
                isTablet && styles.metricValueTablet,
                isLargeScreen && styles.metricValueLarge
              ]}>
                {volatility}
              </Text>
            </View>
          </View>

          <View style={[styles.metricCard, { borderLeftColor: "#f39c12" }]}>
            <Ionicons 
              name="stats-chart" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#f39c12" 
            />
            <View style={styles.metricContent}>
              <Text style={[
                styles.metricLabel,
                isTablet && styles.metricLabelTablet,
                isLargeScreen && styles.metricLabelLarge
              ]}>
                Market State
              </Text>
              <Text style={[
                styles.metricValue,
                isTablet && styles.metricValueTablet,
                isLargeScreen && styles.metricValueLarge
              ]}>
                {marketCondition}
              </Text>
            </View>
          </View>
        </View>

        {/* AI Confidence Indicators */}
        <View style={[
          styles.confidenceContainer,
          isTablet && styles.confidenceContainerTablet,
          isLargeScreen && styles.confidenceContainerLarge
        ]}>
          <View style={styles.confidenceHeader}>
            <Ionicons 
              name="hardware-chip" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#9b59b6" 
            />
            <Text style={[
              styles.confidenceTitle,
              isTablet && styles.confidenceTitleTablet,
              isLargeScreen && styles.confidenceTitleLarge
            ]}>
              AI Confidence Metrics
            </Text>
          </View>
          
          <View style={styles.confidenceMetrics}>
            <View style={styles.confidenceItem}>
              <Text style={[
                styles.confidenceLabel,
                isTablet && styles.confidenceLabelTablet,
                isLargeScreen && styles.confidenceLabelLarge
              ]}>
                Pattern Recognition
              </Text>
              <View style={styles.confidenceBar}>
                <LinearGradient
                  colors={["#3498db", "#2ecc71"]}
                  style={[styles.confidenceProgress, { width: "85%" }]}
                />
              </View>
              <Text style={[
                styles.confidencePercent,
                isTablet && styles.confidencePercentTablet,
                isLargeScreen && styles.confidencePercentLarge
              ]}>
                85%
              </Text>
            </View>

            <View style={styles.confidenceItem}>
              <Text style={[
                styles.confidenceLabel,
                isTablet && styles.confidenceLabelTablet,
                isLargeScreen && styles.confidenceLabelLarge
              ]}>
                Technical Analysis
              </Text>
              <View style={styles.confidenceBar}>
                <LinearGradient
                  colors={["#f39c12", "#e74c3c"]}
                  style={[styles.confidenceProgress, { width: "92%" }]}
                />
              </View>
              <Text style={[
                styles.confidencePercent,
                isTablet && styles.confidencePercentTablet,
                isLargeScreen && styles.confidencePercentLarge
              ]}>
                92%
              </Text>
            </View>

            <View style={styles.confidenceItem}>
              <Text style={[
                styles.confidenceLabel,
                isTablet && styles.confidenceLabelTablet,
                isLargeScreen && styles.confidenceLabelLarge
              ]}>
                Market Context
              </Text>
              <View style={styles.confidenceBar}>
                <LinearGradient
                  colors={["#9b59b6", "#3498db"]}
                  style={[styles.confidenceProgress, { width: "78%" }]}
                />
              </View>
              <Text style={[
                styles.confidencePercent,
                isTablet && styles.confidencePercentTablet,
                isLargeScreen && styles.confidencePercentLarge
              ]}>
                78%
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 30,
  },
  containerTablet: {
    marginBottom: 40,
  },
  containerLarge: {
    marginBottom: 50,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 16,
  },
  sectionTitleTablet: {
    fontSize: 24,
    marginBottom: 20,
  },
  sectionTitleLarge: {
    fontSize: 28,
    marginBottom: 24,
  },
  card: {
    backgroundColor: "rgba(25, 40, 65, 0.9)",
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: "rgba(52, 152, 219, 0.3)",
  },
  cardTablet: {
    borderRadius: 20,
    padding: 32,
    borderWidth: 2,
  },
  cardLarge: {
    borderRadius: 24,
    padding: 40,
    borderWidth: 2,
  },
  gaugeContainer: {
    marginBottom: 24,
  },
  gaugeContainerTablet: {
    marginBottom: 32,
  },
  gaugeContainerLarge: {
    marginBottom: 40,
  },
  gaugeHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  sentimentText: {
    fontSize: 18,
    fontWeight: "bold",
    marginLeft: 12,
  },
  sentimentTextTablet: {
    fontSize: 22,
    marginLeft: 16,
  },
  sentimentTextLarge: {
    fontSize: 26,
    marginLeft: 20,
  },
  gaugeBackground: {
    height: 8,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderRadius: 4,
    overflow: "hidden",
  },
  gaugeBackgroundTablet: {
    height: 10,
    borderRadius: 5,
  },
  gaugeBackgroundLarge: {
    height: 12,
    borderRadius: 6,
  },
  gaugeFill: {
    height: "100%",
    borderRadius: 4,
  },
  gaugeFillTablet: {
    borderRadius: 5,
  },
  gaugeFillLarge: {
    borderRadius: 6,
  },
  metricsGrid: {
    gap: 16,
    marginBottom: 24,
  },
  metricsGridTablet: {
    gap: 20,
    marginBottom: 32,
  },
  metricsGridLarge: {
    gap: 24,
    marginBottom: 40,
  },
  metricCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
  },
  metricContent: {
    marginLeft: 12,
    flex: 1,
  },
  metricLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.6)",
    marginBottom: 4,
  },
  metricLabelTablet: {
    fontSize: 14,
    marginBottom: 6,
  },
  metricLabelLarge: {
    fontSize: 16,
    marginBottom: 8,
  },
  metricValue: {
    fontSize: 16,
    fontWeight: "600",
    color: "#ffffff",
  },
  metricValueTablet: {
    fontSize: 18,
  },
  metricValueLarge: {
    fontSize: 20,
  },
  confidenceContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
  },
  confidenceContainerTablet: {
    borderRadius: 16,
    padding: 20,
  },
  confidenceContainerLarge: {
    borderRadius: 20,
    padding: 24,
  },
  confidenceHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  confidenceTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#9b59b6",
    marginLeft: 8,
  },
  confidenceTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  confidenceTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  confidenceMetrics: {
    gap: 12,
  },
  confidenceItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  confidenceLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.7)",
    flex: 1,
  },
  confidenceLabelTablet: {
    fontSize: 14,
  },
  confidenceLabelLarge: {
    fontSize: 16,
  },
  confidenceBar: {
    flex: 2,
    height: 6,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderRadius: 3,
    overflow: "hidden",
  },
  confidenceProgress: {
    height: "100%",
    borderRadius: 3,
  },
  confidencePercent: {
    fontSize: 12,
    color: "#ffffff",
    fontWeight: "600",
    minWidth: 35,
    textAlign: "right",
  },
  confidencePercentTablet: {
    fontSize: 14,
  },
  confidencePercentLarge: {
    fontSize: 16,
  },
});