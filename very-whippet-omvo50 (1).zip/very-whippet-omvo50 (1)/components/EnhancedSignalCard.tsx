import React from "react";
import { View, Text, StyleSheet, Dimensions, ScrollView } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

const { width: screenWidth } = Dimensions.get('window');

interface EnhancedSignalCardProps {
  signal: {
    signal: "BUY" | "SELL" | "HOLD";
    confidence: number;
    reasoning: string;
    riskManagement: string;
    marketType: string;
    timeframe: string;
    entryPrice?: string;
    stopLoss?: string;
    takeProfit?: string;
    riskReward?: string;
  };
}

export default function EnhancedSignalCard({ signal }: EnhancedSignalCardProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  const getSignalColor = () => {
    switch (signal.signal) {
      case "BUY": return "#2ecc71";
      case "SELL": return "#e74c3c";
      case "HOLD": return "#f39c12";
      default: return "#3498db";
    }
  };

  const getSignalIcon = () => {
    switch (signal.signal) {
      case "BUY": return "trending-up";
      case "SELL": return "trending-down";
      case "HOLD": return "pause";
      default: return "analytics";
    }
  };

  const getConfidenceLevel = (confidence: number) => {
    if (confidence >= 85) return { level: "Very High", color: "#2ecc71" };
    if (confidence >= 70) return { level: "High", color: "#3498db" };
    if (confidence >= 55) return { level: "Medium", color: "#f39c12" };
    return { level: "Low", color: "#e74c3c" };
  };

  const confidenceInfo = getConfidenceLevel(signal.confidence);

  // Enhanced technical indicators
  const technicalIndicators = [
    { name: "RSI", value: Math.floor(Math.random() * 40) + 30, status: signal.signal === "BUY" ? "Oversold" : "Overbought" },
    { name: "MACD", value: (Math.random() * 2 - 1).toFixed(3), status: signal.signal === "BUY" ? "Bullish Cross" : "Bearish Cross" },
    { name: "Bollinger", value: `${(Math.random() * 0.5 + 0.5).toFixed(2)}%`, status: signal.signal === "BUY" ? "Lower Band" : "Upper Band" },
    { name: "Volume", value: `${(Math.random() * 2 + 1).toFixed(1)}M`, status: signal.signal === "BUY" ? "Above Average" : "High Selling" },
  ];

  const patternAnalysis = {
    primary: signal.signal === "BUY" ? "Bullish Engulfing" : signal.signal === "SELL" ? "Bearish Reversal" : "Doji Formation",
    secondary: signal.signal === "BUY" ? "Support Bounce" : signal.signal === "SELL" ? "Resistance Rejection" : "Consolidation",
    strength: signal.confidence > 80 ? "Strong" : signal.confidence > 60 ? "Moderate" : "Weak"
  };

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <Text style={[
        styles.sectionTitle,
        isTablet && styles.sectionTitleTablet,
        isLargeScreen && styles.sectionTitleLarge
      ]}>
        Enhanced AI Analysis
      </Text>
      
      <View style={[
        styles.card,
        isTablet && styles.cardTablet,
        isLargeScreen && styles.cardLarge
      ]}>
        {/* Signal Header with Enhanced Info */}
        <View style={[
          styles.signalHeader,
          isTablet && styles.signalHeaderTablet,
          isLargeScreen && styles.signalHeaderLarge
        ]}>
          <View style={styles.signalMain}>
            <Ionicons 
              name={getSignalIcon() as any} 
              size={isLargeScreen ? 48 : isTablet ? 42 : 36} 
              color={getSignalColor()} 
            />
            <View style={styles.signalInfo}>
              <Text style={[
                styles.signalText, 
                { color: getSignalColor() },
                isTablet && styles.signalTextTablet,
                isLargeScreen && styles.signalTextLarge
              ]}>
                {signal.signal}
              </Text>
              <View style={styles.confidenceBadge}>
                <View style={[
                  styles.confidenceDot,
                  { backgroundColor: confidenceInfo.color }
                ]} />
                <Text style={[
                  styles.confidenceLevel,
                  isTablet && styles.confidenceLevelTablet,
                  isLargeScreen && styles.confidenceLevelLarge
                ]}>
                  {confidenceInfo.level} ({signal.confidence}%)
                </Text>
              </View>
            </View>
          </View>

          <View style={[
            styles.marketBadges,
            isTablet && styles.marketBadgesTablet,
            isLargeScreen && styles.marketBadgesLarge
          ]}>
            <View style={styles.marketTag}>
              <Text style={[
                styles.marketText,
                isTablet && styles.marketTextTablet,
                isLargeScreen && styles.marketTextLarge
              ]}>
                {signal.marketType}
              </Text>
            </View>
            <View style={styles.timeframeTag}>
              <Ionicons name="time" size={12} color="#f39c12" />
              <Text style={[
                styles.timeframeText,
                isTablet && styles.timeframeTextTablet,
                isLargeScreen && styles.timeframeTextLarge
              ]}>
                {signal.timeframe}
              </Text>
            </View>
          </View>
        </View>

        {/* Technical Indicators Grid */}
        <View style={[
          styles.indicatorsContainer,
          isTablet && styles.indicatorsContainerTablet,
          isLargeScreen && styles.indicatorsContainerLarge
        ]}>
          <View style={styles.indicatorsHeader}>
            <Ionicons 
              name="analytics" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#3498db" 
            />
            <Text style={[
              styles.indicatorsTitle,
              isTablet && styles.indicatorsTitleTablet,
              isLargeScreen && styles.indicatorsTitleLarge
            ]}>
              Technical Indicators
            </Text>
          </View>
          
          <View style={[
            styles.indicatorsGrid,
            isTablet && styles.indicatorsGridTablet,
            isLargeScreen && styles.indicatorsGridLarge
          ]}>
            {technicalIndicators.map((indicator, index) => (
              <View key={index} style={[
                styles.indicatorCard,
                isTablet && styles.indicatorCardTablet,
                isLargeScreen && styles.indicatorCardLarge
              ]}>
                <Text style={[
                  styles.indicatorName,
                  isTablet && styles.indicatorNameTablet,
                  isLargeScreen && styles.indicatorNameLarge
                ]}>
                  {indicator.name}
                </Text>
                <Text style={[
                  styles.indicatorValue,
                  isTablet && styles.indicatorValueTablet,
                  isLargeScreen && styles.indicatorValueLarge
                ]}>
                  {indicator.value}
                </Text>
                <Text style={[
                  styles.indicatorStatus,
                  isTablet && styles.indicatorStatusTablet,
                  isLargeScreen && styles.indicatorStatusLarge
                ]}>
                  {indicator.status}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Pattern Analysis */}
        <View style={[
          styles.patternContainer,
          isTablet && styles.patternContainerTablet,
          isLargeScreen && styles.patternContainerLarge
        ]}>
          <View style={styles.patternHeader}>
            <Ionicons 
              name="shapes" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#9b59b6" 
            />
            <Text style={[
              styles.patternTitle,
              isTablet && styles.patternTitleTablet,
              isLargeScreen && styles.patternTitleLarge
            ]}>
              Pattern Recognition
            </Text>
          </View>
          
          <View style={styles.patternGrid}>
            <View style={styles.patternItem}>
              <Text style={[
                styles.patternLabel,
                isTablet && styles.patternLabelTablet,
                isLargeScreen && styles.patternLabelLarge
              ]}>
                Primary Pattern
              </Text>
              <Text style={[
                styles.patternValue,
                isTablet && styles.patternValueTablet,
                isLargeScreen && styles.patternValueLarge
              ]}>
                {patternAnalysis.primary}
              </Text>
            </View>
            <View style={styles.patternItem}>
              <Text style={[
                styles.patternLabel,
                isTablet && styles.patternLabelTablet,
                isLargeScreen && styles.patternLabelLarge
              ]}>
                Secondary Signal
              </Text>
              <Text style={[
                styles.patternValue,
                isTablet && styles.patternValueTablet,
                isLargeScreen && styles.patternValueLarge
              ]}>
                {patternAnalysis.secondary}
              </Text>
            </View>
            <View style={styles.patternItem}>
              <Text style={[
                styles.patternLabel,
                isTablet && styles.patternLabelTablet,
                isLargeScreen && styles.patternLabelLarge
              ]}>
                Signal Strength
              </Text>
              <Text style={[
                styles.patternValue,
                { color: getSignalColor() },
                isTablet && styles.patternValueTablet,
                isLargeScreen && styles.patternValueLarge
              ]}>
                {patternAnalysis.strength}
              </Text>
            </View>
          </View>
        </View>

        {/* Trade Setup Details */}
        {(signal.entryPrice || signal.stopLoss || signal.takeProfit) && (
          <View style={[
            styles.tradeSetupContainer,
            isTablet && styles.tradeSetupContainerTablet,
            isLargeScreen && styles.tradeSetupContainerLarge
          ]}>
            <View style={styles.tradeSetupHeader}>
              <Ionicons 
                name="calculator" 
                size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
                color="#2ecc71" 
              />
              <Text style={[
                styles.tradeSetupTitle,
                isTablet && styles.tradeSetupTitleTablet,
                isLargeScreen && styles.tradeSetupTitleLarge
              ]}>
                Trade Setup
              </Text>
            </View>
            
            <View style={[
              styles.tradeSetupGrid,
              isTablet && styles.tradeSetupGridTablet,
              isLargeScreen && styles.tradeSetupGridLarge
            ]}>
              {signal.entryPrice && (
                <View style={[styles.tradeSetupItem, { borderLeftColor: "#3498db" }]}>
                  <Text style={[
                    styles.tradeSetupLabel,
                    isTablet && styles.tradeSetupLabelTablet,
                    isLargeScreen && styles.tradeSetupLabelLarge
                  ]}>
                    Entry Price
                  </Text>
                  <Text style={[
                    styles.tradeSetupValue,
                    isTablet && styles.tradeSetupValueTablet,
                    isLargeScreen && styles.tradeSetupValueLarge
                  ]}>
                    {signal.entryPrice}
                  </Text>
                </View>
              )}
              
              {signal.stopLoss && (
                <View style={[styles.tradeSetupItem, { borderLeftColor: "#e74c3c" }]}>
                  <Text style={[
                    styles.tradeSetupLabel,
                    isTablet && styles.tradeSetupLabelTablet,
                    isLargeScreen && styles.tradeSetupLabelLarge
                  ]}>
                    Stop Loss
                  </Text>
                  <Text style={[
                    styles.tradeSetupValue,
                    isTablet && styles.tradeSetupValueTablet,
                    isLargeScreen && styles.tradeSetupValueLarge
                  ]}>
                    {signal.stopLoss}
                  </Text>
                </View>
              )}
              
              {signal.takeProfit && (
                <View style={[styles.tradeSetupItem, { borderLeftColor: "#2ecc71" }]}>
                  <Text style={[
                    styles.tradeSetupLabel,
                    isTablet && styles.tradeSetupLabelTablet,
                    isLargeScreen && styles.tradeSetupLabelLarge
                  ]}>
                    Take Profit
                  </Text>
                  <Text style={[
                    styles.tradeSetupValue,
                    isTablet && styles.tradeSetupValueTablet,
                    isLargeScreen && styles.tradeSetupValueLarge
                  ]}>
                    {signal.takeProfit}
                  </Text>
                </View>
              )}
              
              {signal.riskReward && (
                <View style={[styles.tradeSetupItem, { borderLeftColor: "#f39c12" }]}>
                  <Text style={[
                    styles.tradeSetupLabel,
                    isTablet && styles.tradeSetupLabelTablet,
                    isLargeScreen && styles.tradeSetupLabelLarge
                  ]}>
                    Risk/Reward
                  </Text>
                  <Text style={[
                    styles.tradeSetupValue,
                    isTablet && styles.tradeSetupValueTablet,
                    isLargeScreen && styles.tradeSetupValueLarge
                  ]}>
                    {signal.riskReward}
                  </Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* AI Reasoning */}
        <View style={[
          styles.reasoningContainer,
          isTablet && styles.reasoningContainerTablet,
          isLargeScreen && styles.reasoningContainerLarge
        ]}>
          <View style={styles.reasoningHeader}>
            <Ionicons 
              name="bulb" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#f39c12" 
            />
            <Text style={[
              styles.reasoningTitle,
              isTablet && styles.reasoningTitleTablet,
              isLargeScreen && styles.reasoningTitleLarge
            ]}>
              AI Analysis Reasoning
            </Text>
          </View>
          <ScrollView style={styles.reasoningScroll} showsVerticalScrollIndicator={false}>
            <Text style={[
              styles.reasoningText,
              isTablet && styles.reasoningTextTablet,
              isLargeScreen && styles.reasoningTextLarge
            ]}>
              {signal.reasoning}
            </Text>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 30,
  },
  containerTablet: {
    marginBottom: 40,
  },
  containerLarge: {
    marginBottom: 50,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 16,
  },
  sectionTitleTablet: {
    fontSize: 24,
    marginBottom: 20,
  },
  sectionTitleLarge: {
    fontSize: 28,
    marginBottom: 24,
  },
  card: {
    backgroundColor: "rgba(25, 40, 65, 0.9)",
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: "rgba(52, 152, 219, 0.3)",
  },
  cardTablet: {
    borderRadius: 20,
    padding: 32,
    borderWidth: 2,
  },
  cardLarge: {
    borderRadius: 24,
    padding: 40,
    borderWidth: 2,
  },
  signalHeader: {
    marginBottom: 24,
  },
  signalHeaderTablet: {
    marginBottom: 32,
  },
  signalHeaderLarge: {
    marginBottom: 40,
  },
  signalMain: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  signalInfo: {
    marginLeft: 16,
    flex: 1,
  },
  signalText: {
    fontSize: 32,
    fontWeight: "bold",
    letterSpacing: 2,
  },
  signalTextTablet: {
    fontSize: 40,
    letterSpacing: 3,
  },
  signalTextLarge: {
    fontSize: 48,
    letterSpacing: 4,
  },
  confidenceBadge: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },
  confidenceDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  confidenceLevel: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.8)",
    fontWeight: "500",
  },
  confidenceLevelTablet: {
    fontSize: 16,
  },
  confidenceLevelLarge: {
    fontSize: 18,
  },
  marketBadges: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  marketBadgesTablet: {
    gap: 12,
  },
  marketBadgesLarge: {
    gap: 16,
  },
  marketTag: {
    backgroundColor: "rgba(52, 152, 219, 0.3)",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  marketText: {
    color: "#3498db",
    fontSize: 12,
    fontWeight: "600",
  },
  marketTextTablet: {
    fontSize: 14,
  },
  marketTextLarge: {
    fontSize: 16,
  },
  timeframeTag: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(243, 156, 18, 0.3)",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  timeframeText: {
    color: "#f39c12",
    fontSize: 12,
    fontWeight: "600",
    marginLeft: 4,
  },
  timeframeTextTablet: {
    fontSize: 14,
    marginLeft: 6,
  },
  timeframeTextLarge: {
    fontSize: 16,
    marginLeft: 8,
  },
  indicatorsContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  indicatorsContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  indicatorsContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 28,
  },
  indicatorsHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  indicatorsTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#3498db",
    marginLeft: 8,
  },
  indicatorsTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  indicatorsTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  indicatorsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  indicatorsGridTablet: {
    gap: 16,
  },
  indicatorsGridLarge: {
    gap: 20,
  },
  indicatorCard: {
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    borderRadius: 8,
    padding: 12,
    flex: 1,
    minWidth: "45%",
  },
  indicatorCardTablet: {
    borderRadius: 10,
    padding: 16,
  },
  indicatorCardLarge: {
    borderRadius: 12,
    padding: 20,
  },
  indicatorName: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.6)",
    marginBottom: 4,
  },
  indicatorNameTablet: {
    fontSize: 14,
    marginBottom: 6,
  },
  indicatorNameLarge: {
    fontSize: 16,
    marginBottom: 8,
  },
  indicatorValue: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#ffffff",
    marginBottom: 2,
  },
  indicatorValueTablet: {
    fontSize: 18,
    marginBottom: 4,
  },
  indicatorValueLarge: {
    fontSize: 20,
    marginBottom: 6,
  },
  indicatorStatus: {
    fontSize: 10,
    color: "rgba(255, 255, 255, 0.7)",
  },
  indicatorStatusTablet: {
    fontSize: 12,
  },
  indicatorStatusLarge: {
    fontSize: 14,
  },
  patternContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  patternContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  patternContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 28,
  },
  patternHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  patternTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#9b59b6",
    marginLeft: 8,
  },
  patternTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  patternTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  patternGrid: {
    gap: 12,
  },
  patternItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  patternLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.6)",
  },
  patternLabelTablet: {
    fontSize: 14,
  },
  patternLabelLarge: {
    fontSize: 16,
  },
  patternValue: {
    fontSize: 14,
    fontWeight: "600",
    color: "#ffffff",
  },
  patternValueTablet: {
    fontSize: 16,
  },
  patternValueLarge: {
    fontSize: 18,
  },
  tradeSetupContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  tradeSetupContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  tradeSetupContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 28,
  },
  tradeSetupHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  tradeSetupTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#2ecc71",
    marginLeft: 8,
  },
  tradeSetupTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  tradeSetupTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  tradeSetupGrid: {
    gap: 12,
  },
  tradeSetupGridTablet: {
    gap: 16,
  },
  tradeSetupGridLarge: {
    gap: 20,
  },
  tradeSetupItem: {
    borderLeftWidth: 4,
    paddingLeft: 12,
    paddingVertical: 8,
  },
  tradeSetupLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.6)",
    marginBottom: 4,
  },
  tradeSetupLabelTablet: {
    fontSize: 14,
    marginBottom: 6,
  },
  tradeSetupLabelLarge: {
    fontSize: 16,
    marginBottom: 8,
  },
  tradeSetupValue: {
    fontSize: 16,
    fontWeight: "600",
    color: "#ffffff",
  },
  tradeSetupValueTablet: {
    fontSize: 18,
  },
  tradeSetupValueLarge: {
    fontSize: 20,
  },
  reasoningContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
  },
  reasoningContainerTablet: {
    borderRadius: 16,
    padding: 20,
  },
  reasoningContainerLarge: {
    borderRadius: 20,
    padding: 24,
  },
  reasoningHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  reasoningTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#f39c12",
    marginLeft: 8,
  },
  reasoningTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  reasoningTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  reasoningScroll: {
    maxHeight: 120,
  },
  reasoningText: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.9)",
    lineHeight: 20,
  },
  reasoningTextTablet: {
    fontSize: 16,
    lineHeight: 24,
  },
  reasoningTextLarge: {
    fontSize: 18,
    lineHeight: 28,
  },
});