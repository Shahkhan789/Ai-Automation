import React from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

const { width: screenWidth } = Dimensions.get('window');

interface AIInsightsProps {
  insights: {
    marketCondition: string;
    sentiment: string;
    volatility: string;
    keyLevels: {
      support: string;
      resistance: string;
      pivot: string;
    };
    newsImpact: string;
    institutionalFlow: string;
    riskLevel: string;
    aiConfidence: {
      patternRecognition: number;
      technicalAnalysis: number;
      marketContext: number;
    };
    advancedMetrics?: {
      volatilityForecast: string;
      probabilityMatrix: string;
      riskAdjustedReturn: string;
      sharpeRatio: string;
      maxDrawdown: string;
      winRate: string;
    };
  };
}

export default function AIInsights({ insights }: AIInsightsProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  const getVolatilityColor = (volatility: string) => {
    switch (volatility) {
      case "Low": return "#2ecc71";
      case "Medium": return "#f39c12";
      case "High": return "#e74c3c";
      case "Extreme": return "#8e44ad";
      default: return "#3498db";
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "Low": return "#2ecc71";
      case "Medium": return "#f39c12";
      case "High": return "#e74c3c";
      default: return "#3498db";
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case "Bullish": return "trending-up";
      case "Bearish": return "trending-down";
      case "Neutral": return "remove";
      case "Mixed": return "swap-horizontal";
      default: return "analytics";
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return "#2ecc71";
    if (confidence >= 80) return "#3498db";
    if (confidence >= 70) return "#f39c12";
    return "#e74c3c";
  };

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <Text style={[
        styles.sectionTitle,
        isTablet && styles.sectionTitleTablet,
        isLargeScreen && styles.sectionTitleLarge
      ]}>
        Advanced AI Market Intelligence
      </Text>
      
      <View style={[
        styles.card,
        isTablet && styles.cardTablet,
        isLargeScreen && styles.cardLarge
      ]}>
        {/* Enhanced Market Overview */}
        <View style={[
          styles.overviewContainer,
          isTablet && styles.overviewContainerTablet,
          isLargeScreen && styles.overviewContainerLarge
        ]}>
          <View style={styles.overviewItem}>
            <Ionicons 
              name={getSentimentIcon(insights.sentiment) as any} 
              size={isLargeScreen ? 28 : isTablet ? 26 : 24} 
              color="#3498db" 
            />
            <View style={styles.overviewText}>
              <Text style={[
                styles.overviewLabel,
                isTablet && styles.overviewLabelTablet,
                isLargeScreen && styles.overviewLabelLarge
              ]}>
                Market Sentiment
              </Text>
              <Text style={[
                styles.overviewValue,
                isTablet && styles.overviewValueTablet,
                isLargeScreen && styles.overviewValueLarge
              ]}>
                {insights.sentiment}
              </Text>
            </View>
          </View>

          <View style={styles.overviewItem}>
            <Ionicons 
              name="pulse" 
              size={isLargeScreen ? 28 : isTablet ? 26 : 24} 
              color={getVolatilityColor(insights.volatility)} 
            />
            <View style={styles.overviewText}>
              <Text style={[
                styles.overviewLabel,
                isTablet && styles.overviewLabelTablet,
                isLargeScreen && styles.overviewLabelLarge
              ]}>
                Volatility Level
              </Text>
              <Text style={[
                styles.overviewValue,
                { color: getVolatilityColor(insights.volatility) },
                isTablet && styles.overviewValueTablet,
                isLargeScreen && styles.overviewValueLarge
              ]}>
                {insights.volatility}
              </Text>
            </View>
          </View>

          <View style={styles.overviewItem}>
            <Ionicons 
              name="shield-checkmark" 
              size={isLargeScreen ? 28 : isTablet ? 26 : 24} 
              color={getRiskColor(insights.riskLevel)} 
            />
            <View style={styles.overviewText}>
              <Text style={[
                styles.overviewLabel,
                isTablet && styles.overviewLabelTablet,
                isLargeScreen && styles.overviewLabelLarge
              ]}>
                Risk Assessment
              </Text>
              <Text style={[
                styles.overviewValue,
                { color: getRiskColor(insights.riskLevel) },
                isTablet && styles.overviewValueTablet,
                isLargeScreen && styles.overviewValueLarge
              ]}>
                {insights.riskLevel}
              </Text>
            </View>
          </View>
        </View>

        {/* AI Confidence Matrix */}
        <View style={[
          styles.confidenceContainer,
          isTablet && styles.confidenceContainerTablet,
          isLargeScreen && styles.confidenceContainerLarge
        ]}>
          <View style={styles.confidenceHeader}>
            <Ionicons 
              name="hardware-chip" 
              size={isLargeScreen ? 28 : isTablet ? 26 : 24} 
              color="#9b59b6" 
            />
            <Text style={[
              styles.confidenceTitle,
              isTablet && styles.confidenceTitleTablet,
              isLargeScreen && styles.confidenceTitleLarge
            ]}>
              AI Confidence Matrix
            </Text>
          </View>
          
          <View style={styles.confidenceMetrics}>
            <View style={styles.confidenceItem}>
              <View style={styles.confidenceItemHeader}>
                <Ionicons name="eye" size={16} color="#3498db" />
                <Text style={[
                  styles.confidenceLabel,
                  isTablet && styles.confidenceLabelTablet,
                  isLargeScreen && styles.confidenceLabelLarge
                ]}>
                  Pattern Recognition
                </Text>
              </View>
              <View style={styles.confidenceBar}>
                <LinearGradient
                  colors={[getConfidenceColor(insights.aiConfidence.patternRecognition), `${getConfidenceColor(insights.aiConfidence.patternRecognition)}80`]}
                  style={[styles.confidenceProgress, { width: `${insights.aiConfidence.patternRecognition}%` }]}
                />
              </View>
              <Text style={[
                styles.confidencePercent,
                { color: getConfidenceColor(insights.aiConfidence.patternRecognition) },
                isTablet && styles.confidencePercentTablet,
                isLargeScreen && styles.confidencePercentLarge
              ]}>
                {insights.aiConfidence.patternRecognition}%
              </Text>
            </View>

            <View style={styles.confidenceItem}>
              <View style={styles.confidenceItemHeader}>
                <Ionicons name="analytics" size={16} color="#f39c12" />
                <Text style={[
                  styles.confidenceLabel,
                  isTablet && styles.confidenceLabelTablet,
                  isLargeScreen && styles.confidenceLabelLarge
                ]}>
                  Technical Analysis
                </Text>
              </View>
              <View style={styles.confidenceBar}>
                <LinearGradient
                  colors={[getConfidenceColor(insights.aiConfidence.technicalAnalysis), `${getConfidenceColor(insights.aiConfidence.technicalAnalysis)}80`]}
                  style={[styles.confidenceProgress, { width: `${insights.aiConfidence.technicalAnalysis}%` }]}
                />
              </View>
              <Text style={[
                styles.confidencePercent,
                { color: getConfidenceColor(insights.aiConfidence.technicalAnalysis) },
                isTablet && styles.confidencePercentTablet,
                isLargeScreen && styles.confidencePercentLarge
              ]}>
                {insights.aiConfidence.technicalAnalysis}%
              </Text>
            </View>

            <View style={styles.confidenceItem}>
              <View style={styles.confidenceItemHeader}>
                <Ionicons name="globe" size={16} color="#e74c3c" />
                <Text style={[
                  styles.confidenceLabel,
                  isTablet && styles.confidenceLabelTablet,
                  isLargeScreen && styles.confidenceLabelLarge
                ]}>
                  Market Context
                </Text>
              </View>
              <View style={styles.confidenceBar}>
                <LinearGradient
                  colors={[getConfidenceColor(insights.aiConfidence.marketContext), `${getConfidenceColor(insights.aiConfidence.marketContext)}80`]}
                  style={[styles.confidenceProgress, { width: `${insights.aiConfidence.marketContext}%` }]}
                />
              </View>
              <Text style={[
                styles.confidencePercent,
                { color: getConfidenceColor(insights.aiConfidence.marketContext) },
                isTablet && styles.confidencePercentTablet,
                isLargeScreen && styles.confidencePercentLarge
              ]}>
                {insights.aiConfidence.marketContext}%
              </Text>
            </View>
          </View>
        </View>

        {/* Advanced Metrics */}
        {insights.advancedMetrics && (
          <View style={[
            styles.metricsContainer,
            isTablet && styles.metricsContainerTablet,
            isLargeScreen && styles.metricsContainerLarge
          ]}>
            <View style={styles.metricsHeader}>
              <Ionicons 
                name="calculator" 
                size={isLargeScreen ? 28 : isTablet ? 26 : 24} 
                color="#2ecc71" 
              />
              <Text style={[
                styles.metricsTitle,
                isTablet && styles.metricsTitleTablet,
                isLargeScreen && styles.metricsTitleLarge
              ]}>
                Quantitative Analysis
              </Text>
            </View>
            
            <View style={[
              styles.metricsGrid,
              isTablet && styles.metricsGridTablet,
              isLargeScreen && styles.metricsGridLarge
            ]}>
              <View style={[styles.metricCard, { borderLeftColor: "#3498db" }]}>
                <Text style={[
                  styles.metricLabel,
                  isTablet && styles.metricLabelTablet,
                  isLargeScreen && styles.metricLabelLarge
                ]}>
                  Volatility Forecast
                </Text>
                <Text style={[
                  styles.metricValue,
                  isTablet && styles.metricValueTablet,
                  isLargeScreen && styles.metricValueLarge
                ]}>
                  {insights.advancedMetrics.volatilityForecast}
                </Text>
              </View>

              <View style={[styles.metricCard, { borderLeftColor: "#f39c12" }]}>
                <Text style={[
                  styles.metricLabel,
                  isTablet && styles.metricLabelTablet,
                  isLargeScreen && styles.metricLabelLarge
                ]}>
                  Win Rate
                </Text>
                <Text style={[
                  styles.metricValue,
                  isTablet && styles.metricValueTablet,
                  isLargeScreen && styles.metricValueLarge
                ]}>
                  {insights.advancedMetrics.winRate}
                </Text>
              </View>

              <View style={[styles.metricCard, { borderLeftColor: "#2ecc71" }]}>
                <Text style={[
                  styles.metricLabel,
                  isTablet && styles.metricLabelTablet,
                  isLargeScreen && styles.metricLabelLarge
                ]}>
                  Sharpe Ratio
                </Text>
                <Text style={[
                  styles.metricValue,
                  isTablet && styles.metricValueTablet,
                  isLargeScreen && styles.metricValueLarge
                ]}>
                  {insights.advancedMetrics.sharpeRatio}
                </Text>
              </View>

              <View style={[styles.metricCard, { borderLeftColor: "#e74c3c" }]}>
                <Text style={[
                  styles.metricLabel,
                  isTablet && styles.metricLabelTablet,
                  isLargeScreen && styles.metricLabelLarge
                ]}>
                  Max Drawdown
                </Text>
                <Text style={[
                  styles.metricValue,
                  isTablet && styles.metricValueTablet,
                  isLargeScreen && styles.metricValueLarge
                ]}>
                  {insights.advancedMetrics.maxDrawdown}
                </Text>
              </View>

              <View style={[styles.metricCard, { borderLeftColor: "#9b59b6" }]}>
                <Text style={[
                  styles.metricLabel,
                  isTablet && styles.metricLabelTablet,
                  isLargeScreen && styles.metricLabelLarge
                ]}>
                  Expected Return
                </Text>
                <Text style={[
                  styles.metricValue,
                  isTablet && styles.metricValueTablet,
                  isLargeScreen && styles.metricValueLarge
                ]}>
                  {insights.advancedMetrics.riskAdjustedReturn}
                </Text>
              </View>

              <View style={[styles.metricCard, { borderLeftColor: "#1abc9c" }]}>
                <Text style={[
                  styles.metricLabel,
                  isTablet && styles.metricLabelTablet,
                  isLargeScreen && styles.metricLabelLarge
                ]}>
                  Probability Matrix
                </Text>
                <Text style={[
                  styles.metricValue,
                  isTablet && styles.metricValueTablet,
                  isLargeScreen && styles.metricValueLarge
                ]}>
                  {insights.advancedMetrics.probabilityMatrix}
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* Market Condition Analysis */}
        <View style={[
          styles.conditionContainer,
          isTablet && styles.conditionContainerTablet,
          isLargeScreen && styles.conditionContainerLarge
        ]}>
          <View style={styles.conditionHeader}>
            <Ionicons 
              name="stats-chart" 
              size={isLargeScreen ? 28 : isTablet ? 26 : 24} 
              color="#f39c12" 
            />
            <Text style={[
              styles.conditionTitle,
              isTablet && styles.conditionTitleTablet,
              isLargeScreen && styles.conditionTitleLarge
            ]}>
              Market Condition: {insights.marketCondition}
            </Text>
          </View>
        </View>

        {/* Key Levels Analysis */}
        <View style={[
          styles.levelsContainer,
          isTablet && styles.levelsContainerTablet,
          isLargeScreen && styles.levelsContainerLarge
        ]}>
          <View style={styles.levelsHeader}>
            <Ionicons 
              name="layers" 
              size={isLargeScreen ? 28 : isTablet ? 26 : 24} 
              color="#9b59b6" 
            />
            <Text style={[
              styles.levelsTitle,
              isTablet && styles.levelsTitleTablet,
              isLargeScreen && styles.levelsTitleLarge
            ]}>
              AI-Powered Key Levels
            </Text>
          </View>
          <View style={[
            styles.levelsGrid,
            isTablet && styles.levelsGridTablet,
            isLargeScreen && styles.levelsGridLarge
          ]}>
            <View style={[styles.levelItem, { borderLeftColor: "#2ecc71" }]}>
              <Text style={[
                styles.levelLabel,
                isTablet && styles.levelLabelTablet,
                isLargeScreen && styles.levelLabelLarge
              ]}>
                Support Zone
              </Text>
              <Text style={[
                styles.levelValue,
                isTablet && styles.levelValueTablet,
                isLargeScreen && styles.levelValueLarge
              ]}>
                {insights.keyLevels.support}
              </Text>
            </View>
            <View style={[styles.levelItem, { borderLeftColor: "#e74c3c" }]}>
              <Text style={[
                styles.levelLabel,
                isTablet && styles.levelLabelTablet,
                isLargeScreen && styles.levelLabelLarge
              ]}>
                Resistance Zone
              </Text>
              <Text style={[
                styles.levelValue,
                isTablet && styles.levelValueTablet,
                isLargeScreen && styles.levelValueLarge
              ]}>
                {insights.keyLevels.resistance}
              </Text>
            </View>
            <View style={[styles.levelItem, { borderLeftColor: "#f39c12" }]}>
              <Text style={[
                styles.levelLabel,
                isTablet && styles.levelLabelTablet,
                isLargeScreen && styles.levelLabelLarge
              ]}>
                Pivot Point
              </Text>
              <Text style={[
                styles.levelValue,
                isTablet && styles.levelValueTablet,
                isLargeScreen && styles.levelValueLarge
              ]}>
                {insights.keyLevels.pivot}
              </Text>
            </View>
          </View>
        </View>

        {/* Additional Market Intelligence */}
        <View style={[
          styles.additionalContainer,
          isTablet && styles.additionalContainerTablet,
          isLargeScreen && styles.additionalContainerLarge
        ]}>
          <View style={styles.insightRow}>
            <Ionicons 
              name="newspaper" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#3498db" 
            />
            <Text style={[
              styles.insightText,
              isTablet && styles.insightTextTablet,
              isLargeScreen && styles.insightTextLarge
            ]}>
              News Impact Level: <Text style={styles.insightValue}>{insights.newsImpact}</Text>
            </Text>
          </View>
          <View style={styles.insightRow}>
            <Ionicons 
              name="business" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#2ecc71" 
            />
            <Text style={[
              styles.insightText,
              isTablet && styles.insightTextTablet,
              isLargeScreen && styles.insightTextLarge
            ]}>
              Institutional Flow: <Text style={styles.insightValue}>{insights.institutionalFlow}</Text>
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 30,
  },
  containerTablet: {
    marginBottom: 40,
  },
  containerLarge: {
    marginBottom: 50,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 16,
  },
  sectionTitleTablet: {
    fontSize: 24,
    marginBottom: 20,
  },
  sectionTitleLarge: {
    fontSize: 28,
    marginBottom: 24,
  },
  card: {
    backgroundColor: "rgba(25, 40, 65, 0.9)",
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: "rgba(52, 152, 219, 0.3)",
  },
  cardTablet: {
    borderRadius: 20,
    padding: 32,
    borderWidth: 2,
  },
  cardLarge: {
    borderRadius: 24,
    padding: 40,
    borderWidth: 2,
  },
  overviewContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  overviewContainerTablet: {
    marginBottom: 32,
  },
  overviewContainerLarge: {
    marginBottom: 40,
  },
  overviewItem: {
    alignItems: "center",
    flex: 1,
  },
  overviewText: {
    alignItems: "center",
    marginTop: 8,
  },
  overviewLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.6)",
    marginBottom: 4,
    textAlign: "center",
  },
  overviewLabelTablet: {
    fontSize: 14,
    marginBottom: 6,
  },
  overviewLabelLarge: {
    fontSize: 16,
    marginBottom: 8,
  },
  overviewValue: {
    fontSize: 14,
    fontWeight: "600",
    color: "#ffffff",
    textAlign: "center",
  },
  overviewValueTablet: {
    fontSize: 16,
  },
  overviewValueLarge: {
    fontSize: 18,
  },
  confidenceContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  confidenceContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  confidenceContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 28,
  },
  confidenceHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  confidenceTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#9b59b6",
    marginLeft: 8,
  },
  confidenceTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  confidenceTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  confidenceMetrics: {
    gap: 16,
  },
  confidenceItem: {
    gap: 8,
  },
  confidenceItemHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  confidenceLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.7)",
    flex: 1,
  },
  confidenceLabelTablet: {
    fontSize: 14,
  },
  confidenceLabelLarge: {
    fontSize: 16,
  },
  confidenceBar: {
    height: 8,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderRadius: 4,
    overflow: "hidden",
  },
  confidenceProgress: {
    height: "100%",
    borderRadius: 4,
  },
  confidencePercent: {
    fontSize: 12,
    fontWeight: "600",
    textAlign: "right",
  },
  confidencePercentTablet: {
    fontSize: 14,
  },
  confidencePercentLarge: {
    fontSize: 16,
  },
  metricsContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  metricsContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  metricsContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 28,
  },
  metricsHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  metricsTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#2ecc71",
    marginLeft: 8,
  },
  metricsTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  metricsTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  metricsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  metricsGridTablet: {
    gap: 16,
  },
  metricsGridLarge: {
    gap: 20,
  },
  metricCard: {
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    borderRadius: 8,
    padding: 12,
    borderLeftWidth: 4,
    flex: 1,
    minWidth: "45%",
  },
  metricLabel: {
    fontSize: 10,
    color: "rgba(255, 255, 255, 0.6)",
    marginBottom: 4,
  },
  metricLabelTablet: {
    fontSize: 12,
    marginBottom: 6,
  },
  metricLabelLarge: {
    fontSize: 14,
    marginBottom: 8,
  },
  metricValue: {
    fontSize: 12,
    fontWeight: "600",
    color: "#ffffff",
  },
  metricValueTablet: {
    fontSize: 14,
  },
  metricValueLarge: {
    fontSize: 16,
  },
  conditionContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  conditionContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  conditionContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 28,
  },
  conditionHeader: {
    flexDirection: "row",
    alignItems: "center",
  },
  conditionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#f39c12",
    marginLeft: 8,
  },
  conditionTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  conditionTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  levelsContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  levelsContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  levelsContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 28,
  },
  levelsHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  levelsTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#9b59b6",
    marginLeft: 8,
  },
  levelsTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  levelsTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  levelsGrid: {
    gap: 12,
  },
  levelsGridTablet: {
    gap: 16,
  },
  levelsGridLarge: {
    gap: 20,
  },
  levelItem: {
    borderLeftWidth: 4,
    paddingLeft: 12,
    paddingVertical: 8,
  },
  levelLabel: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.6)",
    marginBottom: 4,
  },
  levelLabelTablet: {
    fontSize: 14,
    marginBottom: 6,
  },
  levelLabelLarge: {
    fontSize: 16,
    marginBottom: 8,
  },
  levelValue: {
    fontSize: 14,
    color: "#ffffff",
    fontWeight: "500",
  },
  levelValueTablet: {
    fontSize: 16,
  },
  levelValueLarge: {
    fontSize: 18,
  },
  additionalContainer: {
    gap: 12,
  },
  additionalContainerTablet: {
    gap: 16,
  },
  additionalContainerLarge: {
    gap: 20,
  },
  insightRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  insightText: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.8)",
    marginLeft: 8,
  },
  insightTextTablet: {
    fontSize: 16,
    marginLeft: 10,
  },
  insightTextLarge: {
    fontSize: 18,
    marginLeft: 12,
  },
  insightValue: {
    fontWeight: "600",
    color: "#ffffff",
  },
});