import React from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";

const { width: screenWidth } = Dimensions.get('window');

interface RecentSignalsProps {
  signals: any[] | undefined;
}

export default function RecentSignals({ signals }: RecentSignalsProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  if (!signals || signals.length === 0) {
    return (
      <View style={[
        styles.container,
        isTablet && styles.containerTablet,
        isLargeScreen && styles.containerLarge
      ]}>
        <Text style={[
          styles.sectionTitle,
          isTablet && styles.sectionTitleTablet,
          isLargeScreen && styles.sectionTitleLarge
        ]}>
          Recent Signals
        </Text>
        <View style={[
          styles.emptyState,
          isTablet && styles.emptyStateTablet,
          isLargeScreen && styles.emptyStateLarge
        ]}>
          <Ionicons 
            name="analytics-outline" 
            size={isLargeScreen ? 64 : isTablet ? 56 : 48} 
            color="rgba(255, 255, 255, 0.3)" 
          />
          <Text style={[
            styles.emptyText,
            isTablet && styles.emptyTextTablet,
            isLargeScreen && styles.emptyTextLarge
          ]}>
            No signals yet
          </Text>
          <Text style={[
            styles.emptySubtext,
            isTablet && styles.emptySubtextTablet,
            isLargeScreen && styles.emptySubtextLarge
          ]}>
            Upload your first chart to get started
          </Text>
        </View>
      </View>
    );
  }

  const renderSignalItem = ({ item }: { item: any }) => {
    const getSignalColor = () => {
      switch (item.signal) {
        case "BUY":
          return "#2ecc71";
        case "SELL":
          return "#e74c3c";
        case "HOLD":
          return "#f39c12";
        default:
          return "#3498db";
      }
    };

    const getTimeframeDisplay = (timeframe: string) => {
      const timeframeMap: { [key: string]: string } = {
        "5s": "5s",
        "1m": "1m",
        "5m": "5m",
        "10m": "10m",
        "15m": "15m",
        "30m": "30m",
        "1h": "1h",
        "4h": "4h",
        "1d": "1d",
      };
      return timeframeMap[timeframe] || timeframe;
    };

    const formatDate = (timestamp: number) => {
      const date = new Date(timestamp);
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    };

    return (
      <TouchableOpacity style={[
        styles.signalItem,
        isTablet && styles.signalItemTablet,
        isLargeScreen && styles.signalItemLarge
      ]}>
        <View style={[
          styles.signalContent,
          isTablet && styles.signalContentTablet,
          isLargeScreen && styles.signalContentLarge
        ]}>
          <View style={styles.signalHeader}>
            <View style={styles.signalInfo}>
              <Text style={[
                styles.signalText, 
                { color: getSignalColor() },
                isTablet && styles.signalTextTablet,
                isLargeScreen && styles.signalTextLarge
              ]}>
                {item.signal}
              </Text>
              <View style={[
                styles.tagsContainer,
                isTablet && styles.tagsContainerTablet,
                isLargeScreen && styles.tagsContainerLarge
              ]}>
                <Text style={[
                  styles.marketType,
                  isTablet && styles.marketTypeTablet,
                  isLargeScreen && styles.marketTypeLarge
                ]}>
                  {item.marketType}
                </Text>
                <View style={[
                  styles.timeframeTag,
                  isTablet && styles.timeframeTagTablet,
                  isLargeScreen && styles.timeframeTagLarge
                ]}>
                  <Ionicons 
                    name="time" 
                    size={isLargeScreen ? 12 : isTablet ? 11 : 10} 
                    color="#f39c12" 
                  />
                  <Text style={[
                    styles.timeframeText,
                    isTablet && styles.timeframeTextTablet,
                    isLargeScreen && styles.timeframeTextLarge
                  ]}>
                    {getTimeframeDisplay(item.timeframe)}
                  </Text>
                </View>
              </View>
            </View>
            <Text style={[
              styles.confidence,
              isTablet && styles.confidenceTablet,
              isLargeScreen && styles.confidenceLarge
            ]}>
              {item.confidence}%
            </Text>
          </View>
          
          <Text style={[
            styles.timestamp,
            isTablet && styles.timestampTablet,
            isLargeScreen && styles.timestampLarge
          ]}>
            {formatDate(item._creationTime)}
          </Text>
          
          {item.imageUrl && (
            <Image 
              source={{ uri: item.imageUrl }} 
              style={[
                styles.thumbnail,
                isTablet && styles.thumbnailTablet,
                isLargeScreen && styles.thumbnailLarge
              ]} 
            />
          )}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <Text style={[
        styles.sectionTitle,
        isTablet && styles.sectionTitleTablet,
        isLargeScreen && styles.sectionTitleLarge
      ]}>
        Recent Signals
      </Text>
      <FlatList
        data={signals}
        renderItem={renderSignalItem}
        keyExtractor={(item) => item._id}
        showsVerticalScrollIndicator={false}
        scrollEnabled={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  containerTablet: {
    marginBottom: 30,
  },
  containerLarge: {
    marginBottom: 40,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 16,
  },
  sectionTitleTablet: {
    fontSize: 24,
    marginBottom: 20,
  },
  sectionTitleLarge: {
    fontSize: 28,
    marginBottom: 24,
  },
  emptyState: {
    alignItems: "center",
    paddingVertical: 40,
    paddingHorizontal: 20,
    backgroundColor: "rgba(25, 40, 65, 0.5)",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(52, 152, 219, 0.2)",
  },
  emptyStateTablet: {
    paddingVertical: 60,
    paddingHorizontal: 30,
    borderRadius: 20,
    borderWidth: 2,
  },
  emptyStateLarge: {
    paddingVertical: 80,
    paddingHorizontal: 40,
    borderRadius: 24,
    borderWidth: 2,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "600",
    color: "rgba(255, 255, 255, 0.7)",
    marginTop: 12,
    marginBottom: 4,
  },
  emptyTextTablet: {
    fontSize: 22,
    marginTop: 16,
    marginBottom: 6,
  },
  emptyTextLarge: {
    fontSize: 26,
    marginTop: 20,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.5)",
    textAlign: "center",
  },
  emptySubtextTablet: {
    fontSize: 16,
  },
  emptySubtextLarge: {
    fontSize: 18,
  },
  signalItem: {
    backgroundColor: "rgba(25, 40, 65, 0.7)",
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "rgba(52, 152, 219, 0.2)",
  },
  signalItemTablet: {
    borderRadius: 16,
    marginBottom: 16,
    borderWidth: 2,
  },
  signalItemLarge: {
    borderRadius: 20,
    marginBottom: 20,
    borderWidth: 2,
  },
  signalContent: {
    padding: 16,
  },
  signalContentTablet: {
    padding: 20,
  },
  signalContentLarge: {
    padding: 24,
  },
  signalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 8,
  },
  signalInfo: {
    flex: 1,
  },
  signalText: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 6,
  },
  signalTextTablet: {
    fontSize: 18,
    marginBottom: 8,
  },
  signalTextLarge: {
    fontSize: 20,
    marginBottom: 10,
  },
  tagsContainer: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
  },
  tagsContainerTablet: {
    gap: 8,
  },
  tagsContainerLarge: {
    gap: 10,
  },
  marketType: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.6)",
    backgroundColor: "rgba(52, 152, 219, 0.2)",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    marginRight: 8,
  },
  marketTypeTablet: {
    fontSize: 14,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    marginRight: 0,
  },
  marketTypeLarge: {
    fontSize: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    marginRight: 0,
  },
  timeframeTag: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(243, 156, 18, 0.2)",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  timeframeTagTablet: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
  },
  timeframeTagLarge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  timeframeText: {
    fontSize: 10,
    color: "#f39c12",
    fontWeight: "600",
    marginLeft: 2,
  },
  timeframeTextTablet: {
    fontSize: 12,
    marginLeft: 3,
  },
  timeframeTextLarge: {
    fontSize: 14,
    marginLeft: 4,
  },
  confidence: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.8)",
    fontWeight: "600",
  },
  confidenceTablet: {
    fontSize: 16,
  },
  confidenceLarge: {
    fontSize: 18,
  },
  timestamp: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.5)",
    marginBottom: 8,
  },
  timestampTablet: {
    fontSize: 14,
    marginBottom: 10,
  },
  timestampLarge: {
    fontSize: 16,
    marginBottom: 12,
  },
  thumbnail: {
    width: "100%",
    height: 80,
    borderRadius: 8,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
  },
  thumbnailTablet: {
    height: 100,
    borderRadius: 10,
  },
  thumbnailLarge: {
    height: 120,
    borderRadius: 12,
  },
});