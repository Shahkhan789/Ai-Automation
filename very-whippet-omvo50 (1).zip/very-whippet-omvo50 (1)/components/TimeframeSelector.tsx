import React from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  Dimensions 
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const { width: screenWidth } = Dimensions.get('window');

interface TimeframeSelectorProps {
  selectedTimeframe: string;
  onTimeframeSelect: (timeframe: string) => void;
  tradingType: string;
}

// Different timeframes for different trading types
const getTimeframesForType = (tradingType: string) => {
  switch (tradingType) {
    case "Binary Options":
      return [
        { value: "30s", label: "30 Sec", icon: "flash", color: "#e74c3c" },
        { value: "1m", label: "1 Min", icon: "time", color: "#e74c3c" },
        { value: "2m", label: "2 Min", icon: "timer", color: "#e74c3c" },
        { value: "5m", label: "5 Min", icon: "hourglass", color: "#e74c3c" },
        { value: "10m", label: "10 Min", icon: "stopwatch", color: "#e74c3c" },
        { value: "15m", label: "15 Min", icon: "alarm", color: "#e74c3c" },
      ];
    case "Forex":
      return [
        { value: "1m", label: "1 Min", icon: "time", color: "#3498db" },
        { value: "5m", label: "5 Min", icon: "timer", color: "#3498db" },
        { value: "15m", label: "15 Min", icon: "stopwatch", color: "#3498db" },
        { value: "30m", label: "30 Min", icon: "alarm", color: "#3498db" },
        { value: "1h", label: "1 Hour", icon: "time-outline", color: "#3498db" },
        { value: "4h", label: "4 Hour", icon: "calendar", color: "#3498db" },
        { value: "1d", label: "1 Day", icon: "calendar-outline", color: "#3498db" },
      ];
    case "Crypto":
      return [
        { value: "5s", label: "5 Sec", icon: "flash", color: "#f39c12" },
        { value: "1m", label: "1 Min", icon: "time", color: "#f39c12" },
        { value: "5m", label: "5 Min", icon: "timer", color: "#f39c12" },
        { value: "15m", label: "15 Min", icon: "stopwatch", color: "#f39c12" },
        { value: "1h", label: "1 Hour", icon: "time-outline", color: "#f39c12" },
        { value: "4h", label: "4 Hour", icon: "calendar", color: "#f39c12" },
        { value: "1d", label: "1 Day", icon: "calendar-outline", color: "#f39c12" },
      ];
    case "Stocks":
      return [
        { value: "5m", label: "5 Min", icon: "timer", color: "#2ecc71" },
        { value: "15m", label: "15 Min", icon: "stopwatch", color: "#2ecc71" },
        { value: "30m", label: "30 Min", icon: "alarm", color: "#2ecc71" },
        { value: "1h", label: "1 Hour", icon: "time-outline", color: "#2ecc71" },
        { value: "4h", label: "4 Hour", icon: "calendar", color: "#2ecc71" },
        { value: "1d", label: "1 Day", icon: "calendar-outline", color: "#2ecc71" },
        { value: "1w", label: "1 Week", icon: "calendar-clear", color: "#2ecc71" },
      ];
    default:
      return [
        { value: "1m", label: "1 Min", icon: "time", color: "#3498db" },
        { value: "5m", label: "5 Min", icon: "timer", color: "#3498db" },
        { value: "15m", label: "15 Min", icon: "stopwatch", color: "#3498db" },
        { value: "1h", label: "1 Hour", icon: "time-outline", color: "#3498db" },
        { value: "1d", label: "1 Day", icon: "calendar-outline", color: "#3498db" },
      ];
  }
};

export default function TimeframeSelector({
  selectedTimeframe,
  onTimeframeSelect,
  tradingType,
}: TimeframeSelectorProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  const timeframes = getTimeframesForType(tradingType);
  const showAsGrid = isLargeScreen;

  // Auto-select first timeframe if current selection is not available for this trading type
  React.useEffect(() => {
    const isCurrentTimeframeAvailable = timeframes.some(tf => tf.value === selectedTimeframe);
    if (!isCurrentTimeframeAvailable && timeframes.length > 0) {
      onTimeframeSelect(timeframes[0].value);
    }
  }, [tradingType, selectedTimeframe, onTimeframeSelect]);

  const getTypeColor = () => {
    switch (tradingType) {
      case "Binary Options": return "#e74c3c";
      case "Forex": return "#3498db";
      case "Crypto": return "#f39c12";
      case "Stocks": return "#2ecc71";
      default: return "#3498db";
    }
  };

  const typeColor = getTypeColor();

  if (showAsGrid) {
    return (
      <View style={[
        styles.container,
        isTablet && styles.containerTablet,
        isLargeScreen && styles.containerLarge
      ]}>
        <View style={styles.titleContainer}>
          <Text style={[
            styles.title,
            isTablet && styles.titleTablet,
            isLargeScreen && styles.titleLarge
          ]}>
            Select Timeframe
          </Text>
          {tradingType === "Binary Options" && (
            <View style={[styles.binaryBadge, { backgroundColor: typeColor }]}>
              <Ionicons name="timer" size={14} color="#ffffff" />
              <Text style={styles.binaryBadgeText}>Time-Based</Text>
            </View>
          )}
        </View>
        <View style={styles.gridContainer}>
          {timeframes.map((timeframe) => (
            <TouchableOpacity
              key={timeframe.value}
              style={[
                styles.timeframeButton,
                styles.timeframeButtonGrid,
                isTablet && styles.timeframeButtonTablet,
                isLargeScreen && styles.timeframeButtonLarge,
                selectedTimeframe === timeframe.value && [styles.selectedButton, { backgroundColor: typeColor, borderColor: typeColor }],
              ]}
              onPress={() => onTimeframeSelect(timeframe.value)}
            >
              <Ionicons
                name={timeframe.icon as any}
                size={isLargeScreen ? 24 : isTablet ? 22 : 20}
                color={selectedTimeframe === timeframe.value ? "#ffffff" : typeColor}
              />
              <Text
                style={[
                  styles.timeframeText,
                  isTablet && styles.timeframeTextTablet,
                  isLargeScreen && styles.timeframeTextLarge,
                  selectedTimeframe === timeframe.value && styles.selectedText,
                  { color: selectedTimeframe === timeframe.value ? "#ffffff" : typeColor }
                ]}
              >
                {timeframe.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  }

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <View style={styles.titleContainer}>
        <Text style={[
          styles.title,
          isTablet && styles.titleTablet,
          isLargeScreen && styles.titleLarge
        ]}>
          Select Timeframe
        </Text>
        {tradingType === "Binary Options" && (
          <View style={[styles.binaryBadge, { backgroundColor: typeColor }]}>
            <Ionicons name="timer" size={12} color="#ffffff" />
            <Text style={styles.binaryBadgeText}>Time-Based</Text>
          </View>
        )}
      </View>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          isTablet && styles.scrollContentTablet,
          isLargeScreen && styles.scrollContentLarge
        ]}
      >
        {timeframes.map((timeframe) => (
          <TouchableOpacity
            key={timeframe.value}
            style={[
              styles.timeframeButton,
              isTablet && styles.timeframeButtonTablet,
              isLargeScreen && styles.timeframeButtonLarge,
              selectedTimeframe === timeframe.value && [styles.selectedButton, { backgroundColor: typeColor, borderColor: typeColor }],
              { borderColor: typeColor }
            ]}
            onPress={() => onTimeframeSelect(timeframe.value)}
          >
            <Ionicons
              name={timeframe.icon as any}
              size={isLargeScreen ? 24 : isTablet ? 22 : 20}
              color={selectedTimeframe === timeframe.value ? "#ffffff" : typeColor}
            />
            <Text
              style={[
                styles.timeframeText,
                isTablet && styles.timeframeTextTablet,
                isLargeScreen && styles.timeframeTextLarge,
                selectedTimeframe === timeframe.value && styles.selectedText,
                { color: selectedTimeframe === timeframe.value ? "#ffffff" : typeColor }
              ]}
            >
              {timeframe.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  containerTablet: {
    marginBottom: 30,
  },
  containerLarge: {
    marginBottom: 40,
  },
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: "600",
    color: "#ffffff",
  },
  titleTablet: {
    fontSize: 22,
  },
  titleLarge: {
    fontSize: 26,
  },
  binaryBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  binaryBadgeText: {
    color: "#ffffff",
    fontSize: 10,
    fontWeight: "600",
    marginLeft: 4,
  },
  scrollView: {
    flexGrow: 0,
  },
  scrollContent: {
    paddingRight: 20,
  },
  scrollContentTablet: {
    paddingRight: 30,
  },
  scrollContentLarge: {
    paddingRight: 40,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  timeframeButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderWidth: 2,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginRight: 12,
    minWidth: 80,
  },
  timeframeButtonTablet: {
    borderRadius: 24,
    paddingHorizontal: 20,
    paddingVertical: 12,
    marginRight: 16,
    minWidth: 100,
  },
  timeframeButtonLarge: {
    borderRadius: 28,
    paddingHorizontal: 24,
    paddingVertical: 14,
    marginRight: 0,
    minWidth: 120,
  },
  timeframeButtonGrid: {
    marginRight: 0,
    flex: 1,
    minWidth: '30%',
    maxWidth: '32%',
  },
  selectedButton: {
    borderWidth: 3,
  },
  timeframeText: {
    fontSize: 12,
    fontWeight: "600",
    marginLeft: 6,
  },
  timeframeTextTablet: {
    fontSize: 14,
    marginLeft: 8,
  },
  timeframeTextLarge: {
    fontSize: 16,
    marginLeft: 10,
  },
  selectedText: {
    color: "#ffffff",
  },
});