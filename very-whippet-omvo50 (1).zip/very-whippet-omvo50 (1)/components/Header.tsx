import React from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import { Ionicons } from "@expo/vector-icons";

const { width: screenWidth } = Dimensions.get('window');

export default function Header() {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  return (
    <View style={[
      styles.header,
      isTablet && styles.headerTablet,
      isLargeScreen && styles.headerLarge
    ]}>
      <View style={styles.titleContainer}>
        <Ionicons 
          name="analytics" 
          size={isLargeScreen ? 40 : isTablet ? 36 : 32} 
          color="#3498db" 
        />
        <Text style={[
          styles.title,
          isTablet && styles.titleTablet,
          isLargeScreen && styles.titleLarge
        ]}>
          Trading Signal AI
        </Text>
      </View>
      <Text style={[
        styles.subtitle,
        isTablet && styles.subtitleTablet,
        isLargeScreen && styles.subtitleLarge
      ]}>
        AI-Powered Chart Analysis
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    alignItems: "center",
    paddingVertical: 30,
    paddingHorizontal: 20,
  },
  headerTablet: {
    paddingVertical: 40,
    paddingHorizontal: 30,
  },
  headerLarge: {
    paddingVertical: 50,
    paddingHorizontal: 40,
  },
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#ffffff",
    marginLeft: 12,
  },
  titleTablet: {
    fontSize: 34,
    marginLeft: 16,
  },
  titleLarge: {
    fontSize: 42,
    marginLeft: 20,
  },
  subtitle: {
    fontSize: 16,
    color: "rgba(255, 255, 255, 0.8)",
    textAlign: "center",
  },
  subtitleTablet: {
    fontSize: 18,
  },
  subtitleLarge: {
    fontSize: 20,
  },
});