import React from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

const { width: screenWidth } = Dimensions.get('window');

interface SignalCardProps {
  signal: {
    signal: "BUY" | "SELL" | "HOLD";
    confidence: number;
    reasoning: string;
    riskManagement: string;
    marketType: string;
    timeframe: string;
  };
}

export default function SignalCard({ signal }: SignalCardProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  const getSignalColor = () => {
    switch (signal.signal) {
      case "BUY":
        return "#2ecc71";
      case "SELL":
        return "#e74c3c";
      case "HOLD":
        return "#f39c12";
      default:
        return "#3498db";
    }
  };

  const getSignalIcon = () => {
    switch (signal.signal) {
      case "BUY":
        return "trending-up";
      case "SELL":
        return "trending-down";
      case "HOLD":
        return "pause";
      default:
        return "analytics";
    }
  };

  const getTimeframeDisplay = (timeframe: string) => {
    const timeframeMap: { [key: string]: string } = {
      "5s": "5 Seconds",
      "1m": "1 Minute",
      "5m": "5 Minutes",
      "10m": "10 Minutes",
      "15m": "15 Minutes",
      "30m": "30 Minutes",
      "1h": "1 Hour",
      "4h": "4 Hours",
      "1d": "1 Day",
    };
    return timeframeMap[timeframe] || timeframe;
  };

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <Text style={[
        styles.sectionTitle,
        isTablet && styles.sectionTitleTablet,
        isLargeScreen && styles.sectionTitleLarge
      ]}>
        Analysis Result
      </Text>
      
      <View style={[
        styles.card,
        isTablet && styles.cardTablet,
        isLargeScreen && styles.cardLarge
      ]}>
        <View style={[
          styles.tagsContainer,
          isTablet && styles.tagsContainerTablet,
          isLargeScreen && styles.tagsContainerLarge
        ]}>
          <View style={[
            styles.marketTag,
            isTablet && styles.marketTagTablet,
            isLargeScreen && styles.marketTagLarge
          ]}>
            <Text style={[
              styles.marketText,
              isTablet && styles.marketTextTablet,
              isLargeScreen && styles.marketTextLarge
            ]}>
              {signal.marketType}
            </Text>
          </View>
          <View style={[
            styles.timeframeTag,
            isTablet && styles.timeframeTagTablet,
            isLargeScreen && styles.timeframeTagLarge
          ]}>
            <Ionicons 
              name="time" 
              size={isLargeScreen ? 16 : isTablet ? 14 : 12} 
              color="#f39c12" 
            />
            <Text style={[
              styles.timeframeText,
              isTablet && styles.timeframeTextTablet,
              isLargeScreen && styles.timeframeTextLarge
            ]}>
              {getTimeframeDisplay(signal.timeframe)}
            </Text>
          </View>
        </View>

        <View style={[
          styles.signalContainer,
          isTablet && styles.signalContainerTablet,
          isLargeScreen && styles.signalContainerLarge
        ]}>
          <Ionicons 
            name={getSignalIcon() as any} 
            size={isLargeScreen ? 40 : isTablet ? 36 : 32} 
            color={getSignalColor()} 
          />
          <Text style={[
            styles.signalText, 
            { color: getSignalColor() },
            isTablet && styles.signalTextTablet,
            isLargeScreen && styles.signalTextLarge
          ]}>
            {signal.signal}
          </Text>
        </View>

        <Text style={[
          styles.confidence,
          isTablet && styles.confidenceTablet,
          isLargeScreen && styles.confidenceLarge
        ]}>
          Confidence: {signal.confidence}%
        </Text>

        <View style={[
          styles.progressContainer,
          isTablet && styles.progressContainerTablet,
          isLargeScreen && styles.progressContainerLarge
        ]}>
          <View style={[
            styles.progressBackground,
            isTablet && styles.progressBackgroundTablet,
            isLargeScreen && styles.progressBackgroundLarge
          ]}>
            <LinearGradient
              colors={[getSignalColor(), `${getSignalColor()}80`]}
              style={[
                styles.progressBar, 
                { width: `${signal.confidence}%` },
                isTablet && styles.progressBarTablet,
                isLargeScreen && styles.progressBarLarge
              ]}
            />
          </View>
        </View>

        <View style={[
          styles.reasoningContainer,
          isTablet && styles.reasoningContainerTablet,
          isLargeScreen && styles.reasoningContainerLarge
        ]}>
          <View style={styles.reasoningHeader}>
            <Ionicons 
              name="bulb" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#3498db" 
            />
            <Text style={[
              styles.reasoningTitle,
              isTablet && styles.reasoningTitleTablet,
              isLargeScreen && styles.reasoningTitleLarge
            ]}>
              AI Analysis
            </Text>
          </View>
          <Text style={[
            styles.reasoningText,
            isTablet && styles.reasoningTextTablet,
            isLargeScreen && styles.reasoningTextLarge
          ]}>
            {signal.reasoning}
          </Text>
        </View>

        <View style={[
          styles.riskContainer,
          isTablet && styles.riskContainerTablet,
          isLargeScreen && styles.riskContainerLarge
        ]}>
          <View style={styles.riskHeader}>
            <Ionicons 
              name="shield-checkmark" 
              size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
              color="#f39c12" 
            />
            <Text style={[
              styles.riskTitle,
              isTablet && styles.riskTitleTablet,
              isLargeScreen && styles.riskTitleLarge
            ]}>
              Risk Management
            </Text>
          </View>
          <Text style={[
            styles.riskText,
            isTablet && styles.riskTextTablet,
            isLargeScreen && styles.riskTextLarge
          ]}>
            {signal.riskManagement}
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 30,
  },
  containerTablet: {
    marginBottom: 40,
  },
  containerLarge: {
    marginBottom: 50,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 16,
  },
  sectionTitleTablet: {
    fontSize: 24,
    marginBottom: 20,
  },
  sectionTitleLarge: {
    fontSize: 28,
    marginBottom: 24,
  },
  card: {
    backgroundColor: "rgba(25, 40, 65, 0.9)",
    borderRadius: 16,
    padding: 24,
    borderWidth: 1,
    borderColor: "rgba(52, 152, 219, 0.3)",
  },
  cardTablet: {
    borderRadius: 20,
    padding: 32,
    borderWidth: 2,
  },
  cardLarge: {
    borderRadius: 24,
    padding: 40,
    borderWidth: 2,
  },
  tagsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 20,
  },
  tagsContainerTablet: {
    marginBottom: 24,
  },
  tagsContainerLarge: {
    marginBottom: 28,
  },
  marketTag: {
    backgroundColor: "rgba(52, 152, 219, 0.3)",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
  },
  marketTagTablet: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 24,
    marginRight: 12,
    marginBottom: 12,
  },
  marketTagLarge: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 28,
    marginRight: 16,
    marginBottom: 16,
  },
  marketText: {
    color: "#3498db",
    fontSize: 12,
    fontWeight: "600",
  },
  marketTextTablet: {
    fontSize: 14,
  },
  marketTextLarge: {
    fontSize: 16,
  },
  timeframeTag: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(243, 156, 18, 0.3)",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
  },
  timeframeTagTablet: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 24,
    marginRight: 12,
    marginBottom: 12,
  },
  timeframeTagLarge: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 28,
    marginRight: 16,
    marginBottom: 16,
  },
  timeframeText: {
    color: "#f39c12",
    fontSize: 12,
    fontWeight: "600",
    marginLeft: 4,
  },
  timeframeTextTablet: {
    fontSize: 14,
    marginLeft: 6,
  },
  timeframeTextLarge: {
    fontSize: 16,
    marginLeft: 8,
  },
  signalContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  signalContainerTablet: {
    marginBottom: 16,
  },
  signalContainerLarge: {
    marginBottom: 20,
  },
  signalText: {
    fontSize: 32,
    fontWeight: "bold",
    marginLeft: 12,
    letterSpacing: 2,
  },
  signalTextTablet: {
    fontSize: 40,
    marginLeft: 16,
    letterSpacing: 3,
  },
  signalTextLarge: {
    fontSize: 48,
    marginLeft: 20,
    letterSpacing: 4,
  },
  confidence: {
    textAlign: "center",
    fontSize: 16,
    color: "rgba(255, 255, 255, 0.8)",
    marginBottom: 16,
  },
  confidenceTablet: {
    fontSize: 18,
    marginBottom: 20,
  },
  confidenceLarge: {
    fontSize: 20,
    marginBottom: 24,
  },
  progressContainer: {
    marginBottom: 24,
  },
  progressContainerTablet: {
    marginBottom: 32,
  },
  progressContainerLarge: {
    marginBottom: 40,
  },
  progressBackground: {
    height: 6,
    backgroundColor: "rgba(255, 255, 255, 0.2)",
    borderRadius: 3,
    overflow: "hidden",
  },
  progressBackgroundTablet: {
    height: 8,
    borderRadius: 4,
  },
  progressBackgroundLarge: {
    height: 10,
    borderRadius: 5,
  },
  progressBar: {
    height: "100%",
    borderRadius: 3,
  },
  progressBarTablet: {
    borderRadius: 4,
  },
  progressBarLarge: {
    borderRadius: 5,
  },
  reasoningContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  reasoningContainerTablet: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  reasoningContainerLarge: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
  },
  reasoningHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  reasoningTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#3498db",
    marginLeft: 8,
  },
  reasoningTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  reasoningTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  reasoningText: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.9)",
    lineHeight: 20,
  },
  reasoningTextTablet: {
    fontSize: 16,
    lineHeight: 24,
  },
  reasoningTextLarge: {
    fontSize: 18,
    lineHeight: 28,
  },
  riskContainer: {
    backgroundColor: "rgba(0, 0, 0, 0.3)",
    borderRadius: 12,
    padding: 16,
  },
  riskContainerTablet: {
    borderRadius: 16,
    padding: 20,
  },
  riskContainerLarge: {
    borderRadius: 20,
    padding: 24,
  },
  riskHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  riskTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#f39c12",
    marginLeft: 8,
  },
  riskTitleTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  riskTitleLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  riskText: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.9)",
    lineHeight: 20,
  },
  riskTextTablet: {
    fontSize: 16,
    lineHeight: 24,
  },
  riskTextLarge: {
    fontSize: 18,
    lineHeight: 28,
  },
});