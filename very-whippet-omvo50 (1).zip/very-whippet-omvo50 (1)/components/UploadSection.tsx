import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
} from "react-native";
import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

const { width: screenWidth } = Dimensions.get('window');

interface UploadSectionProps {
  selectedImage: string | null;
  onPickImage: () => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
  analysisProgress?: number;
}

export default function UploadSection({
  selectedImage,
  onPickImage,
  onAnalyze,
  isAnalyzing,
  analysisProgress = 0,
}: UploadSectionProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  const getAnalysisStep = (progress: number) => {
    if (progress <= 15) return "Preprocessing image...";
    if (progress <= 30) return "Detecting chart patterns...";
    if (progress <= 50) return "Analyzing technical indicators...";
    if (progress <= 70) return "Calculating market sentiment...";
    if (progress <= 85) return "Generating risk assessment...";
    return "Finalizing recommendations...";
  };

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <Text style={[
        styles.sectionTitle,
        isTablet && styles.sectionTitleTablet,
        isLargeScreen && styles.sectionTitleLarge
      ]}>
        Upload Chart Screenshot
      </Text>
      
      <TouchableOpacity 
        style={[
          styles.uploadArea,
          isTablet && styles.uploadAreaTablet,
          isLargeScreen && styles.uploadAreaLarge
        ]} 
        onPress={onPickImage}
      >
        {selectedImage ? (
          <View style={styles.imageContainer}>
            <Image 
              source={{ uri: selectedImage }} 
              style={[
                styles.previewImage,
                isTablet && styles.previewImageTablet,
                isLargeScreen && styles.previewImageLarge
              ]} 
            />
            <View style={styles.imageOverlay}>
              <Ionicons 
                name="camera" 
                size={isLargeScreen ? 32 : isTablet ? 28 : 24} 
                color="#ffffff" 
              />
              <Text style={[
                styles.changeText,
                isTablet && styles.changeTextTablet,
                isLargeScreen && styles.changeTextLarge
              ]}>
                Tap to change
              </Text>
            </View>
          </View>
        ) : (
          <View style={[
            styles.uploadPrompt,
            isTablet && styles.uploadPromptTablet,
            isLargeScreen && styles.uploadPromptLarge
          ]}>
            <Ionicons 
              name="cloud-upload-outline" 
              size={isLargeScreen ? 64 : isTablet ? 56 : 48} 
              color="#3498db" 
            />
            <Text style={[
              styles.uploadTitle,
              isTablet && styles.uploadTitleTablet,
              isLargeScreen && styles.uploadTitleLarge
            ]}>
              Upload Chart Image
            </Text>
            <Text style={[
              styles.uploadSubtitle,
              isTablet && styles.uploadSubtitleTablet,
              isLargeScreen && styles.uploadSubtitleLarge
            ]}>
              Supports PNG, JPG • Max 5MB
            </Text>
          </View>
        )}
      </TouchableOpacity>

      {selectedImage && (
        <TouchableOpacity
          style={[
            styles.analyzeButton, 
            isAnalyzing && styles.analyzeButtonDisabled,
            isTablet && styles.analyzeButtonTablet,
            isLargeScreen && styles.analyzeButtonLarge
          ]}
          onPress={onAnalyze}
          disabled={isAnalyzing}
        >
          <LinearGradient
            colors={isAnalyzing ? ["#7f8c8d", "#95a5a6"] : ["#3498db", "#2ecc71"]}
            style={[
              styles.analyzeGradient,
              isTablet && styles.analyzeGradientTablet,
              isLargeScreen && styles.analyzeGradientLarge
            ]}
          >
            {isAnalyzing ? (
              <View style={styles.loadingContainer}>
                <View style={styles.progressContainer}>
                  <View style={[
                    styles.progressBackground,
                    isTablet && styles.progressBackgroundTablet,
                    isLargeScreen && styles.progressBackgroundLarge
                  ]}>
                    <LinearGradient
                      colors={["#3498db", "#2ecc71"]}
                      style={[
                        styles.progressBar,
                        { width: `${analysisProgress}%` },
                        isTablet && styles.progressBarTablet,
                        isLargeScreen && styles.progressBarLarge
                      ]}
                    />
                  </View>
                  <Text style={[
                    styles.progressText,
                    isTablet && styles.progressTextTablet,
                    isLargeScreen && styles.progressTextLarge
                  ]}>
                    {analysisProgress}%
                  </Text>
                </View>
                <Text style={[
                  styles.analyzeText,
                  isTablet && styles.analyzeTextTablet,
                  isLargeScreen && styles.analyzeTextLarge
                ]}>
                  {getAnalysisStep(analysisProgress)}
                </Text>
                <View style={styles.aiIndicator}>
                  <Ionicons 
                    name="hardware-chip" 
                    size={isLargeScreen ? 20 : isTablet ? 18 : 16} 
                    color="#ffffff" 
                  />
                  <Text style={[
                    styles.aiText,
                    isTablet && styles.aiTextTablet,
                    isLargeScreen && styles.aiTextLarge
                  ]}>
                    AI Processing
                  </Text>
                </View>
              </View>
            ) : (
              <View style={styles.analyzeContainer}>
                <Ionicons 
                  name="flash" 
                  size={isLargeScreen ? 24 : isTablet ? 22 : 20} 
                  color="#ffffff" 
                />
                <Text style={[
                  styles.analyzeText,
                  isTablet && styles.analyzeTextTablet,
                  isLargeScreen && styles.analyzeTextLarge
                ]}>
                  Analyze with AI
                </Text>
              </View>
            )}
          </LinearGradient>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 30,
  },
  containerTablet: {
    marginBottom: 40,
  },
  containerLarge: {
    marginBottom: 50,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 16,
  },
  sectionTitleTablet: {
    fontSize: 24,
    marginBottom: 20,
  },
  sectionTitleLarge: {
    fontSize: 28,
    marginBottom: 24,
  },
  uploadArea: {
    borderWidth: 2,
    borderColor: "#3498db",
    borderStyle: "dashed",
    borderRadius: 16,
    backgroundColor: "rgba(52, 152, 219, 0.1)",
    overflow: "hidden",
  },
  uploadAreaTablet: {
    borderRadius: 20,
    borderWidth: 3,
  },
  uploadAreaLarge: {
    borderRadius: 24,
    borderWidth: 3,
  },
  uploadPrompt: {
    alignItems: "center",
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  uploadPromptTablet: {
    paddingVertical: 60,
    paddingHorizontal: 30,
  },
  uploadPromptLarge: {
    paddingVertical: 80,
    paddingHorizontal: 40,
  },
  uploadTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#ffffff",
    marginTop: 12,
    marginBottom: 4,
  },
  uploadTitleTablet: {
    fontSize: 22,
    marginTop: 16,
    marginBottom: 6,
  },
  uploadTitleLarge: {
    fontSize: 26,
    marginTop: 20,
    marginBottom: 8,
  },
  uploadSubtitle: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.7)",
  },
  uploadSubtitleTablet: {
    fontSize: 16,
  },
  uploadSubtitleLarge: {
    fontSize: 18,
  },
  imageContainer: {
    position: "relative",
  },
  previewImage: {
    width: "100%",
    height: 200,
    borderRadius: 14,
  },
  previewImageTablet: {
    height: 280,
    borderRadius: 18,
  },
  previewImageLarge: {
    height: 360,
    borderRadius: 22,
  },
  imageOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 14,
  },
  changeText: {
    color: "#ffffff",
    fontSize: 14,
    marginTop: 4,
  },
  changeTextTablet: {
    fontSize: 16,
    marginTop: 6,
  },
  changeTextLarge: {
    fontSize: 18,
    marginTop: 8,
  },
  analyzeButton: {
    marginTop: 16,
    borderRadius: 12,
    overflow: "hidden",
  },
  analyzeButtonTablet: {
    marginTop: 20,
    borderRadius: 16,
  },
  analyzeButtonLarge: {
    marginTop: 24,
    borderRadius: 20,
  },
  analyzeButtonDisabled: {
    opacity: 0.9,
  },
  analyzeGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: "center",
  },
  analyzeGradientTablet: {
    paddingVertical: 20,
    paddingHorizontal: 32,
  },
  analyzeGradientLarge: {
    paddingVertical: 24,
    paddingHorizontal: 40,
  },
  analyzeContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  loadingContainer: {
    alignItems: "center",
    width: "100%",
  },
  progressContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    marginBottom: 12,
  },
  progressBackground: {
    flex: 1,
    height: 6,
    backgroundColor: "rgba(255, 255, 255, 0.3)",
    borderRadius: 3,
    overflow: "hidden",
    marginRight: 12,
  },
  progressBackgroundTablet: {
    height: 8,
    borderRadius: 4,
  },
  progressBackgroundLarge: {
    height: 10,
    borderRadius: 5,
  },
  progressBar: {
    height: "100%",
    borderRadius: 3,
  },
  progressBarTablet: {
    borderRadius: 4,
  },
  progressBarLarge: {
    borderRadius: 5,
  },
  progressText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    minWidth: 40,
  },
  progressTextTablet: {
    fontSize: 16,
  },
  progressTextLarge: {
    fontSize: 18,
  },
  analyzeText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "600",
    marginLeft: 8,
    textAlign: "center",
  },
  analyzeTextTablet: {
    fontSize: 18,
    marginLeft: 10,
  },
  analyzeTextLarge: {
    fontSize: 20,
    marginLeft: 12,
  },
  aiIndicator: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },
  aiText: {
    color: "rgba(255, 255, 255, 0.8)",
    fontSize: 12,
    marginLeft: 6,
  },
  aiTextTablet: {
    fontSize: 14,
    marginLeft: 8,
  },
  aiTextLarge: {
    fontSize: 16,
    marginLeft: 10,
  },
});