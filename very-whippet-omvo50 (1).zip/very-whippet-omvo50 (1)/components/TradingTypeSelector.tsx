import React from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ScrollView, 
  Dimensions 
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const { width: screenWidth } = Dimensions.get('window');

interface TradingTypeSelectorProps {
  selectedType: string;
  onTypeSelect: (type: string) => void;
}

const tradingTypes = [
  { 
    value: "Forex", 
    label: "Forex", 
    icon: "globe-outline",
    color: "#3498db",
    description: "Currency Pairs"
  },
  { 
    value: "Crypto", 
    label: "Crypto", 
    icon: "logo-bitcoin",
    color: "#f39c12",
    description: "Digital Assets"
  },
  { 
    value: "Binary Options", 
    label: "Binary", 
    icon: "timer-outline",
    color: "#e74c3c",
    description: "Time-Based Trading"
  },
  { 
    value: "Stocks", 
    label: "Stocks", 
    icon: "trending-up",
    color: "#2ecc71",
    description: "Equity Markets"
  },
];

export default function TradingTypeSelector({
  selectedType,
  onTypeSelect,
}: TradingTypeSelectorProps) {
  const isTablet = screenWidth >= 768;
  const isLargeScreen = screenWidth >= 1024;

  // For large screens, show as a grid instead of horizontal scroll
  const showAsGrid = isLargeScreen;

  if (showAsGrid) {
    return (
      <View style={[
        styles.container,
        isTablet && styles.containerTablet,
        isLargeScreen && styles.containerLarge
      ]}>
        <Text style={[
          styles.title,
          isTablet && styles.titleTablet,
          isLargeScreen && styles.titleLarge
        ]}>
          Select Trading Type
        </Text>
        <View style={styles.gridContainer}>
          {tradingTypes.map((type) => (
            <TouchableOpacity
              key={type.value}
              style={[
                styles.typeButton,
                styles.typeButtonGrid,
                isTablet && styles.typeButtonTablet,
                isLargeScreen && styles.typeButtonLarge,
                selectedType === type.value && [styles.selectedButton, { borderColor: type.color }],
              ]}
              onPress={() => onTypeSelect(type.value)}
            >
              <Ionicons
                name={type.icon as any}
                size={isLargeScreen ? 32 : isTablet ? 28 : 24}
                color={selectedType === type.value ? "#ffffff" : type.color}
              />
              <Text
                style={[
                  styles.typeText,
                  isTablet && styles.typeTextTablet,
                  isLargeScreen && styles.typeTextLarge,
                  selectedType === type.value && styles.selectedText,
                ]}
              >
                {type.label}
              </Text>
              <Text
                style={[
                  styles.typeDescription,
                  isTablet && styles.typeDescriptionTablet,
                  isLargeScreen && styles.typeDescriptionLarge,
                  selectedType === type.value && styles.selectedDescription,
                ]}
              >
                {type.description}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  }

  return (
    <View style={[
      styles.container,
      isTablet && styles.containerTablet,
      isLargeScreen && styles.containerLarge
    ]}>
      <Text style={[
        styles.title,
        isTablet && styles.titleTablet,
        isLargeScreen && styles.titleLarge
      ]}>
        Select Trading Type
      </Text>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          isTablet && styles.scrollContentTablet,
          isLargeScreen && styles.scrollContentLarge
        ]}
      >
        {tradingTypes.map((type) => (
          <TouchableOpacity
            key={type.value}
            style={[
              styles.typeButton,
              isTablet && styles.typeButtonTablet,
              isLargeScreen && styles.typeButtonLarge,
              selectedType === type.value && [styles.selectedButton, { borderColor: type.color, backgroundColor: type.color }],
            ]}
            onPress={() => onTypeSelect(type.value)}
          >
            <Ionicons
              name={type.icon as any}
              size={isLargeScreen ? 28 : isTablet ? 26 : 22}
              color={selectedType === type.value ? "#ffffff" : type.color}
            />
            <Text
              style={[
                styles.typeText,
                isTablet && styles.typeTextTablet,
                isLargeScreen && styles.typeTextLarge,
                selectedType === type.value && styles.selectedText,
              ]}
            >
              {type.label}
            </Text>
            <Text
              style={[
                styles.typeDescription,
                isTablet && styles.typeDescriptionTablet,
                isLargeScreen && styles.typeDescriptionLarge,
                selectedType === type.value && styles.selectedDescription,
              ]}
            >
              {type.description}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  containerTablet: {
    marginBottom: 30,
  },
  containerLarge: {
    marginBottom: 40,
  },
  title: {
    fontSize: 18,
    fontWeight: "600",
    color: "#ffffff",
    marginBottom: 12,
  },
  titleTablet: {
    fontSize: 22,
    marginBottom: 16,
  },
  titleLarge: {
    fontSize: 26,
    marginBottom: 20,
  },
  scrollView: {
    flexGrow: 0,
  },
  scrollContent: {
    paddingRight: 20,
  },
  scrollContentTablet: {
    paddingRight: 30,
  },
  scrollContentLarge: {
    paddingRight: 40,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  typeButton: {
    alignItems: "center",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderWidth: 2,
    borderColor: "rgba(255, 255, 255, 0.3)",
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    minWidth: 100,
  },
  typeButtonTablet: {
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 16,
    marginRight: 16,
    minWidth: 120,
  },
  typeButtonLarge: {
    borderRadius: 24,
    paddingHorizontal: 24,
    paddingVertical: 20,
    marginRight: 0,
    minWidth: 140,
  },
  typeButtonGrid: {
    marginRight: 0,
    flex: 1,
    minWidth: '22%',
    maxWidth: '24%',
  },
  selectedButton: {
    borderWidth: 3,
  },
  typeText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginTop: 6,
    textAlign: "center",
  },
  typeTextTablet: {
    fontSize: 16,
    marginTop: 8,
  },
  typeTextLarge: {
    fontSize: 18,
    marginTop: 10,
  },
  selectedText: {
    color: "#ffffff",
  },
  typeDescription: {
    color: "rgba(255, 255, 255, 0.6)",
    fontSize: 10,
    marginTop: 2,
    textAlign: "center",
  },
  typeDescriptionTablet: {
    fontSize: 12,
    marginTop: 4,
  },
  typeDescriptionLarge: {
    fontSize: 14,
    marginTop: 6,
  },
  selectedDescription: {
    color: "rgba(255, 255, 255, 0.9)",
  },
});