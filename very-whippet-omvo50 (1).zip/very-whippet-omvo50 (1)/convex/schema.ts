import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  tradingSignals: defineTable({
    imageId: v.id("_storage"),
    signal: v.union(v.literal("BUY"), v.literal("SELL"), v.literal("HOLD")),
    confidence: v.number(),
    reasoning: v.string(),
    riskManagement: v.string(),
    marketType: v.union(
      v.literal("Forex"), 
      v.literal("Crypto"), 
      v.literal("Binary Options"),
      v.literal("Stocks")
    ),
    timeframe: v.union(
      v.literal("5s"),
      v.literal("30s"),
      v.literal("1m"),
      v.literal("2m"),
      v.literal("5m"),
      v.literal("10m"),
      v.literal("15m"),
      v.literal("30m"),
      v.literal("1h"),
      v.literal("4h"),
      v.literal("1d"),
      v.literal("1w")
    ),
    entryPrice: v.optional(v.string()),
    stopLoss: v.optional(v.string()),
    takeProfit: v.optional(v.string()),
    riskReward: v.optional(v.string()),
  }),
});