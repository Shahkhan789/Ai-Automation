import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const signals = await ctx.db
      .query("tradingSignals")
      .order("desc")
      .take(20);
    
    // Get image URLs for each signal
    const signalsWithUrls = await Promise.all(
      signals.map(async (signal) => {
        const imageUrl = await ctx.storage.getUrl(signal.imageId);
        return {
          ...signal,
          imageUrl,
        };
      })
    );
    
    return signalsWithUrls;
  },
});

export const create = mutation({
  args: {
    imageId: v.id("_storage"),
    signal: v.union(v.literal("BUY"), v.literal("SELL"), v.literal("HOLD")),
    confidence: v.number(),
    reasoning: v.string(),
    riskManagement: v.string(),
    marketType: v.union(
      v.literal("Forex"), 
      v.literal("Crypto"), 
      v.literal("Binary Options"),
      v.literal("Stocks")
    ),
    timeframe: v.union(
      v.literal("5s"),
      v.literal("30s"),
      v.literal("1m"),
      v.literal("2m"),
      v.literal("5m"),
      v.literal("10m"),
      v.literal("15m"),
      v.literal("30m"),
      v.literal("1h"),
      v.literal("4h"),
      v.literal("1d"),
      v.literal("1w")
    ),
    entryPrice: v.optional(v.string()),
    stopLoss: v.optional(v.string()),
    takeProfit: v.optional(v.string()),
    riskReward: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const signalId = await ctx.db.insert("tradingSignals", args);
    return signalId;
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});